import engine_main

import engine
import engine_input

engine_input.rumble(1.0)

while True:
    engine.tick()