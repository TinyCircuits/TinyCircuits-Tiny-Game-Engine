#ifndef ENGINE_IO_SDL_H
#define ENGINE_IO_SDL_H

void engine_io_sdl_update_pressed_mask();

#endif  // ENGINE_IO_SDL_H