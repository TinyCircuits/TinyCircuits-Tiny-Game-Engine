// Main version for firmware
#define ENGINE_VER_MAJOR 0
#define ENGINE_VER_MINOR 0
#define ENGINE_VER_PATCH 0

// Version for save files
#define SAVE_VERSION 0