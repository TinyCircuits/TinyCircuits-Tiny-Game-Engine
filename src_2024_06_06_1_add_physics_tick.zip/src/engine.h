#ifndef ENGINE_H
#define ENGINE_H

float engine_fps_limit_period_ms;

#endif  // ENGINE_H