#ifndef ENGINE_MAIN_H
#define ENGINE_MAIN_H

void engine_main_raise_if_not_initialized();
void engine_main_reset();

#endif  // ENGINE_MAIN_H