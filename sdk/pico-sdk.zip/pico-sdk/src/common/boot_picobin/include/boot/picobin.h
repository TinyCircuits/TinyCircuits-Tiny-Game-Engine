/*
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef _BOOT_PICOBIN_H
#define _BOOT_PICOBIN_H

#ifndef NO_PICO_PLATFORM
#include "pico.h"
#endif

/** \file picobin.h
*  \defgroup boot_picobin boot_picobin
*
* Constants for PICOBIN format
*/

// these are designed to not look like (likely) 16/32-bit ARM or RISC-V instructions or look like valid pointers
#define PICOBIN_BLOCK_MARKER_START 0xffffded3
#define PICOBIN_BLOCK_MARKER_END   0xab123579

#define PICOBIN_MAX_BLOCK_SIZE 1024
// todo amy doesn't belong here, but handy place for now

#define PICOBIN_BLOCK_ITEM_1BS_NEXT_BLOCK_OFFSET        0x01
#define PICOBIN_BLOCK_ITEM_1BS_EXE_TYPE                 0x02
#define PICOBIN_BLOCK_ITEM_1BS_VECTOR_TABLE             0X03
#define PICOBIN_BLOCK_ITEM_1BS_ENTRY_POINT              0X04
#define PICOBIN_BLOCK_ITEM_1BS_ROLLING_WINDOW_DELTA     0X05
#define PICOBIN_BLOCK_ITEM_LOAD_MAP                     0X06
#define PICOBIN_BLOCK_ITEM_1BS_HASH_DEF                 0X07
#define PICOBIN_BLOCK_ITEM_OTP_VERSION                  0X08
#define PICOBIN_BLOCK_ITEM_SIGNATURE                    0X09

#define PICOBIN_BLOCK_ITEM_2BS_LAST             (0x80 | 0x7f)

#define PICOBIN_EXE_TYPE_APP_TYPE_MASK         0x000f
#define PICOBIN_EXE_TYPE_APP_TYPE_INVALID      0x0000
#define PICOBIN_EXE_TYPE_APP_TYPE_REGULAR      0x0001
#define PICOBIN_EXE_TYPE_APP_TYPE_XIP_SETUP    0x0002
#define PICOBIN_EXE_TYPE_APP_TYPE_BOOTLOADER   0x0003

#define PICOBIN_EXE_TYPE_SECURITY_MASK         0x0030
#define PICOBIN_EXE_TYPE_SECURITY_UNSPECIFIED  0x0000
#define PICOBIN_EXE_TYPE_SECURITY_NS           0x0010
#define PICOBIN_EXE_TYPE_SECURITY_S            0x0020

#define PICOBIN_EXE_TYPE_CPU_MASK              0x00c0
#define PICOBIN_EXE_TYPE_CPU_ARM               0x0000
#define PICOBIN_EXE_TYPE_CPU_RISCV             0x0040

#define PICOBIN_EXE_TYPE_CHIP_MASK             0x0f00
#define PICOBIN_EXE_TYPE_CHIP_RP2040           0x0000
#define PICOBIN_EXE_TYPE_CHIP_RP2350           0x0100

// todo not sure this is super helpful
#define PICOBIN_EXE_TYPE_CHIP_REVISION         0x7000

// todo assert no overlap ^

#define PICOBIN_HASH_SHA256                    0x01

#define PICOBIN_SIGNATURE_SECP256K1            0x01

#ifndef __ASSEMBLER__
typedef struct {
    uint32_t storage_address_rel;
    uint32_t runtime_address;
    uint32_t size;
} picobin_load_map_entry;

typedef struct {
    uint32_t header;
    picobin_load_map_entry entries[];
} picobin_load_map;

static inline uint picobin_load_map_entry_count(const picobin_load_map *lm) {
    return lm->header >> 24;
}
#endif

#endif
