/*
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef _PICO_BOOTROM_CONSTANTS_H
#define _PICO_BOOTROM_CONSTANTS_H

#include "pico.h"

#define BOOT_TO_PC_MAGIC 0xb007c0d3
#define BOOT_TO_BOOTSEL_MAGIC_PC 0xb1273aff

/** \file bootrom.h
 * \defgroup pico_bootrom pico_bootrom
 * Access to functions and data in the on-device bootrom
 *
 * This header may be included by assembly code
 */

// ROOT ADDRESSES
#if defined(__riscv)
#define BOOTROM_MAGIC_OFFSET 0x7dec
#define BOOTROM_FUNC_TABLE_OFFSET 0x7df0
#define BOOTROM_TABLE_LOOKUP_OFFSET 0x7df4
#else
#define BOOTROM_VTABLE_OFFSET 0x00
#define BOOTROM_MAGIC_OFFSET 0x10
#define BOOTROM_FUNC_TABLE_OFFSET 0x14
#if PICO_RP2040
#define BOOTROM_DATA_TABLE_OFFSET 0x16
#endif
#define BOOTROM_TABLE_LOOKUP_OFFSET 0x18
#endif

#if !PICO_RP2040
#define RT_ARM_FUNC 0x1
#define RT_RISCV_FUNC 0x2
#define RT_V6M (0x4 | RT_ARM_FUNC)
#define RT_V8M (0x8 | RT_ARM_FUNC)
#define RT_SEC 0x10
#define RT_NONSEC 0x20
#define RT_DATA 0x40
#define RT_EXEMPT (RT_SEC | RT_NONSEC)
#endif

/*! \brief Return a bootrom lookup code based on two ASCII characters
 * \ingroup pico_bootrom
 *
 * These codes are uses to lookup data or function addresses in the bootrom
 *
 * \param c1 the first character
 * \param c2 the second character
 * \return the 'code' to use in rom_func_lookup() or rom_data_lookup()
 */
#define ROM_TABLE_CODE(c1, c2) ((c1) | ((c2) << 8))

// ROM FUNCTIONS

// todo amy remove some of these
#define ROM_FUNC_POPCOUNT32                 ROM_TABLE_CODE('P', '3')
#define ROM_FUNC_REVERSE32                  ROM_TABLE_CODE('R', '3')
#define ROM_FUNC_CLZ32                      ROM_TABLE_CODE('L', '3')
#define ROM_FUNC_CTZ32                      ROM_TABLE_CODE('T', '3')
#define ROM_FUNC_MEMSET                     ROM_TABLE_CODE('M', 'S')
#define ROM_FUNC_MEMSET4                    ROM_TABLE_CODE('S', '4')
#define ROM_FUNC_MEMCPY                     ROM_TABLE_CODE('M', 'C')
#define ROM_FUNC_MEMCPY44                   ROM_TABLE_CODE('C', '4')
#define ROM_FUNC_BOOTROM_STATE_RESET        ROM_TABLE_CODE('S', 'R')
#define ROM_FUNC_RESET_USB_BOOT             ROM_TABLE_CODE('U', 'B')
#define ROM_FUNC_CONNECT_INTERNAL_FLASH     ROM_TABLE_CODE('I', 'F')
#define ROM_FUNC_FLASH_EXIT_XIP             ROM_TABLE_CODE('E', 'X')
#define ROM_FUNC_FLASH_RANGE_ERASE          ROM_TABLE_CODE('R', 'E')
#define ROM_FUNC_FLASH_RANGE_PROGRAM        ROM_TABLE_CODE('R', 'P')
#define ROM_FUNC_FLASH_FLUSH_CACHE          ROM_TABLE_CODE('F', 'C')
#define ROM_FUNC_FLASH_ENTER_CMD_XIP        ROM_TABLE_CODE('C', 'X')
#define ROM_FUNC_FLASH_SELECT_XIP_READ_MODE ROM_TABLE_CODE('X', 'M')
#define ROM_FUNC_BOOT_RANDOM                ROM_TABLE_CODE('B', 'R')
#define ROM_FUNC_OTP_PROGRAM_BLOCKING       ROM_TABLE_CODE('O', 'P')

// these form a bit set
#define BOOTROM_STATE_RESET_CURRENT_CORE 0x01
#define BOOTROM_STATE_RESET_OTHER_CORE   0x02
#define BOOTROM_STATE_RESET_GLOBAL_STATE 0x04 // reset any global state (e.g. permissions)
#endif
