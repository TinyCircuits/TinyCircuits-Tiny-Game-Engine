/*
 * Copyright (c) 2022 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef _PICO_CYW43_ARCH_ARCH_POLL_H
#define _PICO_CYW43_ARCH_ARCH_POLL_H

// now obsolete; kept for backwards compatibility

#endif
