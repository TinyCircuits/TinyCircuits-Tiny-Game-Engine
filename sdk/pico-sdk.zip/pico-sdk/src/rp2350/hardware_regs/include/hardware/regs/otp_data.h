/**
 * Copyright (c) 2023 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
// =============================================================================
// Register block : OTP_DATA
// Version        : 1
// Bus type       : apb
// Description    : Predefined OTP data layout for RP2350
// =============================================================================
#ifndef HARDWARE_REGS_OTP_DATA_DEFINED
#define HARDWARE_REGS_OTP_DATA_DEFINED
// =============================================================================
// Register    : OTP_DATA_CHIPID_DEVICE0
// Description : Lower 16 bits of test lot/device number (ECC)
#define OTP_DATA_CHIPID_DEVICE0_OFFSET _u(0x00000000)
#define OTP_DATA_CHIPID_DEVICE0_BITS   _u(0x0000ffff)
#define OTP_DATA_CHIPID_DEVICE0_RESET  "-"
#define OTP_DATA_CHIPID_DEVICE0_MSB    _u(15)
#define OTP_DATA_CHIPID_DEVICE0_LSB    _u(0)
#define OTP_DATA_CHIPID_DEVICE0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CHIPID_DEVICE1
// Description : Upper 16 bits of test lot/device number (ECC)
#define OTP_DATA_CHIPID_DEVICE1_OFFSET _u(0x00000002)
#define OTP_DATA_CHIPID_DEVICE1_BITS   _u(0x0000ffff)
#define OTP_DATA_CHIPID_DEVICE1_RESET  "-"
#define OTP_DATA_CHIPID_DEVICE1_MSB    _u(15)
#define OTP_DATA_CHIPID_DEVICE1_LSB    _u(0)
#define OTP_DATA_CHIPID_DEVICE1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CHIPID_WAFER0
// Description : Lower 16 bits of wafer lot (ECC)
#define OTP_DATA_CHIPID_WAFER0_OFFSET _u(0x00000004)
#define OTP_DATA_CHIPID_WAFER0_BITS   _u(0x0000ffff)
#define OTP_DATA_CHIPID_WAFER0_RESET  "-"
#define OTP_DATA_CHIPID_WAFER0_MSB    _u(15)
#define OTP_DATA_CHIPID_WAFER0_LSB    _u(0)
#define OTP_DATA_CHIPID_WAFER0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CHIPID_WAFER1
// Description : Upper 16 bits of wafer lot (ECC)
#define OTP_DATA_CHIPID_WAFER1_OFFSET _u(0x00000006)
#define OTP_DATA_CHIPID_WAFER1_BITS   _u(0x0000ffff)
#define OTP_DATA_CHIPID_WAFER1_RESET  "-"
#define OTP_DATA_CHIPID_WAFER1_MSB    _u(15)
#define OTP_DATA_CHIPID_WAFER1_LSB    _u(0)
#define OTP_DATA_CHIPID_WAFER1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_RANDID0
// Description : 16 bits of random data sampled from the TRNG during
//               manufacturing (ECC)
#define OTP_DATA_RANDID0_OFFSET _u(0x00000008)
#define OTP_DATA_RANDID0_BITS   _u(0x0000ffff)
#define OTP_DATA_RANDID0_RESET  "-"
#define OTP_DATA_RANDID0_MSB    _u(15)
#define OTP_DATA_RANDID0_LSB    _u(0)
#define OTP_DATA_RANDID0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_RANDID1
// Description : 16 bits of random data sampled from the TRNG during
//               manufacturing (ECC)
#define OTP_DATA_RANDID1_OFFSET _u(0x0000000a)
#define OTP_DATA_RANDID1_BITS   _u(0x0000ffff)
#define OTP_DATA_RANDID1_RESET  "-"
#define OTP_DATA_RANDID1_MSB    _u(15)
#define OTP_DATA_RANDID1_LSB    _u(0)
#define OTP_DATA_RANDID1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_RANDID2
// Description : 16 bits of random data sampled from the TRNG during
//               manufacturing (ECC)
#define OTP_DATA_RANDID2_OFFSET _u(0x0000000c)
#define OTP_DATA_RANDID2_BITS   _u(0x0000ffff)
#define OTP_DATA_RANDID2_RESET  "-"
#define OTP_DATA_RANDID2_MSB    _u(15)
#define OTP_DATA_RANDID2_LSB    _u(0)
#define OTP_DATA_RANDID2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_RANDID3
// Description : 16 bits of random data sampled from the TRNG during
//               manufacturing (ECC)
#define OTP_DATA_RANDID3_OFFSET _u(0x0000000e)
#define OTP_DATA_RANDID3_BITS   _u(0x0000ffff)
#define OTP_DATA_RANDID3_RESET  "-"
#define OTP_DATA_RANDID3_MSB    _u(15)
#define OTP_DATA_RANDID3_LSB    _u(0)
#define OTP_DATA_RANDID3_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_RANDID4
// Description : 16 bits of random data sampled from the TRNG during
//               manufacturing (ECC)
#define OTP_DATA_RANDID4_OFFSET _u(0x00000010)
#define OTP_DATA_RANDID4_BITS   _u(0x0000ffff)
#define OTP_DATA_RANDID4_RESET  "-"
#define OTP_DATA_RANDID4_MSB    _u(15)
#define OTP_DATA_RANDID4_LSB    _u(0)
#define OTP_DATA_RANDID4_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_RANDID5
// Description : 16 bits of random data sampled from the TRNG during
//               manufacturing (ECC)
#define OTP_DATA_RANDID5_OFFSET _u(0x00000012)
#define OTP_DATA_RANDID5_BITS   _u(0x0000ffff)
#define OTP_DATA_RANDID5_RESET  "-"
#define OTP_DATA_RANDID5_MSB    _u(15)
#define OTP_DATA_RANDID5_LSB    _u(0)
#define OTP_DATA_RANDID5_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_RANDID6
// Description : 16 bits of random data sampled from the TRNG during
//               manufacturing (ECC)
#define OTP_DATA_RANDID6_OFFSET _u(0x00000014)
#define OTP_DATA_RANDID6_BITS   _u(0x0000ffff)
#define OTP_DATA_RANDID6_RESET  "-"
#define OTP_DATA_RANDID6_MSB    _u(15)
#define OTP_DATA_RANDID6_LSB    _u(0)
#define OTP_DATA_RANDID6_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_RANDID7
// Description : 16 bits of random data sampled from the TRNG during
//               manufacturing (ECC)
#define OTP_DATA_RANDID7_OFFSET _u(0x00000016)
#define OTP_DATA_RANDID7_BITS   _u(0x0000ffff)
#define OTP_DATA_RANDID7_RESET  "-"
#define OTP_DATA_RANDID7_MSB    _u(15)
#define OTP_DATA_RANDID7_LSB    _u(0)
#define OTP_DATA_RANDID7_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_ROSC_CALIB
// Description : Ring oscillator calibration constant measured during
//               manufacturing (ECC)
#define OTP_DATA_ROSC_CALIB_OFFSET _u(0x00000020)
#define OTP_DATA_ROSC_CALIB_BITS   _u(0x0000ffff)
#define OTP_DATA_ROSC_CALIB_RESET  "-"
#define OTP_DATA_ROSC_CALIB_MSB    _u(15)
#define OTP_DATA_ROSC_CALIB_LSB    _u(0)
#define OTP_DATA_ROSC_CALIB_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_LPOSC_CALIB
// Description : Low-power oscillator calibration constant measured during
//               manufacturing (ECC)
#define OTP_DATA_LPOSC_CALIB_OFFSET _u(0x00000022)
#define OTP_DATA_LPOSC_CALIB_BITS   _u(0x0000ffff)
#define OTP_DATA_LPOSC_CALIB_RESET  "-"
#define OTP_DATA_LPOSC_CALIB_MSB    _u(15)
#define OTP_DATA_LPOSC_CALIB_LSB    _u(0)
#define OTP_DATA_LPOSC_CALIB_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_INFO_CRC0
// Description : Lower 16 bits of CRC32 of OTP addresses 0x00 through 0x6b
//               (polynomial 0x4c11db7, input reflected, output reflected, seed
//               all-ones, final XOR all-ones) (ECC)
#define OTP_DATA_INFO_CRC0_OFFSET _u(0x0000006c)
#define OTP_DATA_INFO_CRC0_BITS   _u(0x0000ffff)
#define OTP_DATA_INFO_CRC0_RESET  "-"
#define OTP_DATA_INFO_CRC0_MSB    _u(15)
#define OTP_DATA_INFO_CRC0_LSB    _u(0)
#define OTP_DATA_INFO_CRC0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_INFO_CRC1
// Description : Upper 16 bits of CRC32 of OTP addresses 0x00 through 0x6b (ECC)
#define OTP_DATA_INFO_CRC1_OFFSET _u(0x0000006e)
#define OTP_DATA_INFO_CRC1_BITS   _u(0x0000ffff)
#define OTP_DATA_INFO_CRC1_RESET  "-"
#define OTP_DATA_INFO_CRC1_MSB    _u(15)
#define OTP_DATA_INFO_CRC1_LSB    _u(0)
#define OTP_DATA_INFO_CRC1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT0
// Description : Page 0 critical boot flags (RBIT-8)
#define OTP_DATA_CRIT0_OFFSET _u(0x00000070)
#define OTP_DATA_CRIT0_BITS   _u(0x00000003)
#define OTP_DATA_CRIT0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_CRIT0_RISCV_DISABLE
// Description : Permanently disable RISC-V processors (Hazard3)
#define OTP_DATA_CRIT0_RISCV_DISABLE_RESET  "-"
#define OTP_DATA_CRIT0_RISCV_DISABLE_BITS   _u(0x00000002)
#define OTP_DATA_CRIT0_RISCV_DISABLE_MSB    _u(1)
#define OTP_DATA_CRIT0_RISCV_DISABLE_LSB    _u(1)
#define OTP_DATA_CRIT0_RISCV_DISABLE_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_CRIT0_ARM_DISABLE
// Description : Permanently disable Arm processors (Cortex-M33)
#define OTP_DATA_CRIT0_ARM_DISABLE_RESET  "-"
#define OTP_DATA_CRIT0_ARM_DISABLE_BITS   _u(0x00000001)
#define OTP_DATA_CRIT0_ARM_DISABLE_MSB    _u(0)
#define OTP_DATA_CRIT0_ARM_DISABLE_LSB    _u(0)
#define OTP_DATA_CRIT0_ARM_DISABLE_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT0_R1
// Description : Redundant copy of CRIT0
#define OTP_DATA_CRIT0_R1_OFFSET _u(0x00000072)
#define OTP_DATA_CRIT0_R1_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT0_R1_RESET  "-"
#define OTP_DATA_CRIT0_R1_MSB    _u(23)
#define OTP_DATA_CRIT0_R1_LSB    _u(0)
#define OTP_DATA_CRIT0_R1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT0_R2
// Description : Redundant copy of CRIT0
#define OTP_DATA_CRIT0_R2_OFFSET _u(0x00000074)
#define OTP_DATA_CRIT0_R2_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT0_R2_RESET  "-"
#define OTP_DATA_CRIT0_R2_MSB    _u(23)
#define OTP_DATA_CRIT0_R2_LSB    _u(0)
#define OTP_DATA_CRIT0_R2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT0_R3
// Description : Redundant copy of CRIT0
#define OTP_DATA_CRIT0_R3_OFFSET _u(0x00000076)
#define OTP_DATA_CRIT0_R3_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT0_R3_RESET  "-"
#define OTP_DATA_CRIT0_R3_MSB    _u(23)
#define OTP_DATA_CRIT0_R3_LSB    _u(0)
#define OTP_DATA_CRIT0_R3_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT0_R4
// Description : Redundant copy of CRIT0
#define OTP_DATA_CRIT0_R4_OFFSET _u(0x00000078)
#define OTP_DATA_CRIT0_R4_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT0_R4_RESET  "-"
#define OTP_DATA_CRIT0_R4_MSB    _u(23)
#define OTP_DATA_CRIT0_R4_LSB    _u(0)
#define OTP_DATA_CRIT0_R4_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT0_R5
// Description : Redundant copy of CRIT0
#define OTP_DATA_CRIT0_R5_OFFSET _u(0x0000007a)
#define OTP_DATA_CRIT0_R5_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT0_R5_RESET  "-"
#define OTP_DATA_CRIT0_R5_MSB    _u(23)
#define OTP_DATA_CRIT0_R5_LSB    _u(0)
#define OTP_DATA_CRIT0_R5_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT0_R6
// Description : Redundant copy of CRIT0
#define OTP_DATA_CRIT0_R6_OFFSET _u(0x0000007c)
#define OTP_DATA_CRIT0_R6_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT0_R6_RESET  "-"
#define OTP_DATA_CRIT0_R6_MSB    _u(23)
#define OTP_DATA_CRIT0_R6_LSB    _u(0)
#define OTP_DATA_CRIT0_R6_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT0_R7
// Description : Redundant copy of CRIT0
#define OTP_DATA_CRIT0_R7_OFFSET _u(0x0000007e)
#define OTP_DATA_CRIT0_R7_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT0_R7_RESET  "-"
#define OTP_DATA_CRIT0_R7_MSB    _u(23)
#define OTP_DATA_CRIT0_R7_LSB    _u(0)
#define OTP_DATA_CRIT0_R7_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT1
// Description : Page 1 critical boot flags (RBIT-8)
#define OTP_DATA_CRIT1_OFFSET _u(0x00000080)
#define OTP_DATA_CRIT1_BITS   _u(0x0000007f)
#define OTP_DATA_CRIT1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_CRIT1_GLITCH_DETECTOR_SENS
// Description : Increase the sensitivity of the glitch detectors from their
//               default.
#define OTP_DATA_CRIT1_GLITCH_DETECTOR_SENS_RESET  "-"
#define OTP_DATA_CRIT1_GLITCH_DETECTOR_SENS_BITS   _u(0x00000060)
#define OTP_DATA_CRIT1_GLITCH_DETECTOR_SENS_MSB    _u(6)
#define OTP_DATA_CRIT1_GLITCH_DETECTOR_SENS_LSB    _u(5)
#define OTP_DATA_CRIT1_GLITCH_DETECTOR_SENS_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_CRIT1_GLITCH_DETECTOR_ENABLE
// Description : Arm the glitch detectors to reset the system if an abnormal
//               clock/power event is observed.
#define OTP_DATA_CRIT1_GLITCH_DETECTOR_ENABLE_RESET  "-"
#define OTP_DATA_CRIT1_GLITCH_DETECTOR_ENABLE_BITS   _u(0x00000010)
#define OTP_DATA_CRIT1_GLITCH_DETECTOR_ENABLE_MSB    _u(4)
#define OTP_DATA_CRIT1_GLITCH_DETECTOR_ENABLE_LSB    _u(4)
#define OTP_DATA_CRIT1_GLITCH_DETECTOR_ENABLE_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_CRIT1_BOOT_ARCH
// Description : Set the default boot architecture, 0=Arm 1=RISC-V. Ignored if
//               ARM_DISABLE, RISCV_DISABLE or SECURE_BOOT_ENABLE is set.
#define OTP_DATA_CRIT1_BOOT_ARCH_RESET  "-"
#define OTP_DATA_CRIT1_BOOT_ARCH_BITS   _u(0x00000008)
#define OTP_DATA_CRIT1_BOOT_ARCH_MSB    _u(3)
#define OTP_DATA_CRIT1_BOOT_ARCH_LSB    _u(3)
#define OTP_DATA_CRIT1_BOOT_ARCH_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_CRIT1_DEBUG_DISABLE
// Description : Disable all debug access
#define OTP_DATA_CRIT1_DEBUG_DISABLE_RESET  "-"
#define OTP_DATA_CRIT1_DEBUG_DISABLE_BITS   _u(0x00000004)
#define OTP_DATA_CRIT1_DEBUG_DISABLE_MSB    _u(2)
#define OTP_DATA_CRIT1_DEBUG_DISABLE_LSB    _u(2)
#define OTP_DATA_CRIT1_DEBUG_DISABLE_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_CRIT1_SECURE_DEBUG_DISABLE
// Description : Disable Secure debug access
#define OTP_DATA_CRIT1_SECURE_DEBUG_DISABLE_RESET  "-"
#define OTP_DATA_CRIT1_SECURE_DEBUG_DISABLE_BITS   _u(0x00000002)
#define OTP_DATA_CRIT1_SECURE_DEBUG_DISABLE_MSB    _u(1)
#define OTP_DATA_CRIT1_SECURE_DEBUG_DISABLE_LSB    _u(1)
#define OTP_DATA_CRIT1_SECURE_DEBUG_DISABLE_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_CRIT1_SECURE_BOOT_ENABLE
// Description : Enable boot signature enforcement, and permanently disable the
//               RISC-V cores.
#define OTP_DATA_CRIT1_SECURE_BOOT_ENABLE_RESET  "-"
#define OTP_DATA_CRIT1_SECURE_BOOT_ENABLE_BITS   _u(0x00000001)
#define OTP_DATA_CRIT1_SECURE_BOOT_ENABLE_MSB    _u(0)
#define OTP_DATA_CRIT1_SECURE_BOOT_ENABLE_LSB    _u(0)
#define OTP_DATA_CRIT1_SECURE_BOOT_ENABLE_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT1_R1
// Description : Redundant copy of CRIT1
#define OTP_DATA_CRIT1_R1_OFFSET _u(0x00000082)
#define OTP_DATA_CRIT1_R1_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT1_R1_RESET  "-"
#define OTP_DATA_CRIT1_R1_MSB    _u(23)
#define OTP_DATA_CRIT1_R1_LSB    _u(0)
#define OTP_DATA_CRIT1_R1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT1_R2
// Description : Redundant copy of CRIT1
#define OTP_DATA_CRIT1_R2_OFFSET _u(0x00000084)
#define OTP_DATA_CRIT1_R2_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT1_R2_RESET  "-"
#define OTP_DATA_CRIT1_R2_MSB    _u(23)
#define OTP_DATA_CRIT1_R2_LSB    _u(0)
#define OTP_DATA_CRIT1_R2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT1_R3
// Description : Redundant copy of CRIT1
#define OTP_DATA_CRIT1_R3_OFFSET _u(0x00000086)
#define OTP_DATA_CRIT1_R3_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT1_R3_RESET  "-"
#define OTP_DATA_CRIT1_R3_MSB    _u(23)
#define OTP_DATA_CRIT1_R3_LSB    _u(0)
#define OTP_DATA_CRIT1_R3_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT1_R4
// Description : Redundant copy of CRIT1
#define OTP_DATA_CRIT1_R4_OFFSET _u(0x00000088)
#define OTP_DATA_CRIT1_R4_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT1_R4_RESET  "-"
#define OTP_DATA_CRIT1_R4_MSB    _u(23)
#define OTP_DATA_CRIT1_R4_LSB    _u(0)
#define OTP_DATA_CRIT1_R4_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT1_R5
// Description : Redundant copy of CRIT1
#define OTP_DATA_CRIT1_R5_OFFSET _u(0x0000008a)
#define OTP_DATA_CRIT1_R5_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT1_R5_RESET  "-"
#define OTP_DATA_CRIT1_R5_MSB    _u(23)
#define OTP_DATA_CRIT1_R5_LSB    _u(0)
#define OTP_DATA_CRIT1_R5_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT1_R6
// Description : Redundant copy of CRIT1
#define OTP_DATA_CRIT1_R6_OFFSET _u(0x0000008c)
#define OTP_DATA_CRIT1_R6_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT1_R6_RESET  "-"
#define OTP_DATA_CRIT1_R6_MSB    _u(23)
#define OTP_DATA_CRIT1_R6_LSB    _u(0)
#define OTP_DATA_CRIT1_R6_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_CRIT1_R7
// Description : Redundant copy of CRIT1
#define OTP_DATA_CRIT1_R7_OFFSET _u(0x0000008e)
#define OTP_DATA_CRIT1_R7_BITS   _u(0x00ffffff)
#define OTP_DATA_CRIT1_R7_RESET  "-"
#define OTP_DATA_CRIT1_R7_MSB    _u(23)
#define OTP_DATA_CRIT1_R7_LSB    _u(0)
#define OTP_DATA_CRIT1_R7_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY0
// Description : Bits 15:0 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY0_OFFSET _u(0x00000090)
#define OTP_DATA_BOOTKEY0_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY0_RESET  "-"
#define OTP_DATA_BOOTKEY0_MSB    _u(15)
#define OTP_DATA_BOOTKEY0_LSB    _u(0)
#define OTP_DATA_BOOTKEY0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY1
// Description : Bits 31:16 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY1_OFFSET _u(0x00000092)
#define OTP_DATA_BOOTKEY1_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY1_RESET  "-"
#define OTP_DATA_BOOTKEY1_MSB    _u(15)
#define OTP_DATA_BOOTKEY1_LSB    _u(0)
#define OTP_DATA_BOOTKEY1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY2
// Description : Bits 47:32 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY2_OFFSET _u(0x00000094)
#define OTP_DATA_BOOTKEY2_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY2_RESET  "-"
#define OTP_DATA_BOOTKEY2_MSB    _u(15)
#define OTP_DATA_BOOTKEY2_LSB    _u(0)
#define OTP_DATA_BOOTKEY2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY3
// Description : Bits 63:48 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY3_OFFSET _u(0x00000096)
#define OTP_DATA_BOOTKEY3_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY3_RESET  "-"
#define OTP_DATA_BOOTKEY3_MSB    _u(15)
#define OTP_DATA_BOOTKEY3_LSB    _u(0)
#define OTP_DATA_BOOTKEY3_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY4
// Description : Bits 79:64 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY4_OFFSET _u(0x00000098)
#define OTP_DATA_BOOTKEY4_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY4_RESET  "-"
#define OTP_DATA_BOOTKEY4_MSB    _u(15)
#define OTP_DATA_BOOTKEY4_LSB    _u(0)
#define OTP_DATA_BOOTKEY4_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY5
// Description : Bits 95:80 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY5_OFFSET _u(0x0000009a)
#define OTP_DATA_BOOTKEY5_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY5_RESET  "-"
#define OTP_DATA_BOOTKEY5_MSB    _u(15)
#define OTP_DATA_BOOTKEY5_LSB    _u(0)
#define OTP_DATA_BOOTKEY5_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY6
// Description : Bits 111:96 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY6_OFFSET _u(0x0000009c)
#define OTP_DATA_BOOTKEY6_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY6_RESET  "-"
#define OTP_DATA_BOOTKEY6_MSB    _u(15)
#define OTP_DATA_BOOTKEY6_LSB    _u(0)
#define OTP_DATA_BOOTKEY6_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY7
// Description : Bits 127:112 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY7_OFFSET _u(0x0000009e)
#define OTP_DATA_BOOTKEY7_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY7_RESET  "-"
#define OTP_DATA_BOOTKEY7_MSB    _u(15)
#define OTP_DATA_BOOTKEY7_LSB    _u(0)
#define OTP_DATA_BOOTKEY7_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY8
// Description : Bits 143:128 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY8_OFFSET _u(0x000000a0)
#define OTP_DATA_BOOTKEY8_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY8_RESET  "-"
#define OTP_DATA_BOOTKEY8_MSB    _u(15)
#define OTP_DATA_BOOTKEY8_LSB    _u(0)
#define OTP_DATA_BOOTKEY8_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY9
// Description : Bits 159:144 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY9_OFFSET _u(0x000000a2)
#define OTP_DATA_BOOTKEY9_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY9_RESET  "-"
#define OTP_DATA_BOOTKEY9_MSB    _u(15)
#define OTP_DATA_BOOTKEY9_LSB    _u(0)
#define OTP_DATA_BOOTKEY9_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY10
// Description : Bits 175:160 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY10_OFFSET _u(0x000000a4)
#define OTP_DATA_BOOTKEY10_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY10_RESET  "-"
#define OTP_DATA_BOOTKEY10_MSB    _u(15)
#define OTP_DATA_BOOTKEY10_LSB    _u(0)
#define OTP_DATA_BOOTKEY10_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY11
// Description : Bits 191:176 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY11_OFFSET _u(0x000000a6)
#define OTP_DATA_BOOTKEY11_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY11_RESET  "-"
#define OTP_DATA_BOOTKEY11_MSB    _u(15)
#define OTP_DATA_BOOTKEY11_LSB    _u(0)
#define OTP_DATA_BOOTKEY11_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY12
// Description : Bits 207:192 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY12_OFFSET _u(0x000000a8)
#define OTP_DATA_BOOTKEY12_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY12_RESET  "-"
#define OTP_DATA_BOOTKEY12_MSB    _u(15)
#define OTP_DATA_BOOTKEY12_LSB    _u(0)
#define OTP_DATA_BOOTKEY12_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY13
// Description : Bits 223:208 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY13_OFFSET _u(0x000000aa)
#define OTP_DATA_BOOTKEY13_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY13_RESET  "-"
#define OTP_DATA_BOOTKEY13_MSB    _u(15)
#define OTP_DATA_BOOTKEY13_LSB    _u(0)
#define OTP_DATA_BOOTKEY13_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY14
// Description : Bits 239:224 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY14_OFFSET _u(0x000000ac)
#define OTP_DATA_BOOTKEY14_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY14_RESET  "-"
#define OTP_DATA_BOOTKEY14_MSB    _u(15)
#define OTP_DATA_BOOTKEY14_LSB    _u(0)
#define OTP_DATA_BOOTKEY14_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTKEY15
// Description : Bits 255:240 of SHA-256 hash of boot signing key (ECC)
#define OTP_DATA_BOOTKEY15_OFFSET _u(0x000000ae)
#define OTP_DATA_BOOTKEY15_BITS   _u(0x0000ffff)
#define OTP_DATA_BOOTKEY15_RESET  "-"
#define OTP_DATA_BOOTKEY15_MSB    _u(15)
#define OTP_DATA_BOOTKEY15_LSB    _u(0)
#define OTP_DATA_BOOTKEY15_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTVERSION0
// Description : Boot version thermometer counter, bits 23:0 (RBIT-3)
#define OTP_DATA_BOOTVERSION0_OFFSET _u(0x000000b0)
#define OTP_DATA_BOOTVERSION0_BITS   _u(0x00ffffff)
#define OTP_DATA_BOOTVERSION0_RESET  "-"
#define OTP_DATA_BOOTVERSION0_MSB    _u(23)
#define OTP_DATA_BOOTVERSION0_LSB    _u(0)
#define OTP_DATA_BOOTVERSION0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTVERSION0_R1
// Description : Redundant copy of BOOTVERSION0
#define OTP_DATA_BOOTVERSION0_R1_OFFSET _u(0x000000b2)
#define OTP_DATA_BOOTVERSION0_R1_BITS   _u(0x00ffffff)
#define OTP_DATA_BOOTVERSION0_R1_RESET  "-"
#define OTP_DATA_BOOTVERSION0_R1_MSB    _u(23)
#define OTP_DATA_BOOTVERSION0_R1_LSB    _u(0)
#define OTP_DATA_BOOTVERSION0_R1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTVERSION0_R2
// Description : Redundant copy of BOOTVERSION0
#define OTP_DATA_BOOTVERSION0_R2_OFFSET _u(0x000000b4)
#define OTP_DATA_BOOTVERSION0_R2_BITS   _u(0x00ffffff)
#define OTP_DATA_BOOTVERSION0_R2_RESET  "-"
#define OTP_DATA_BOOTVERSION0_R2_MSB    _u(23)
#define OTP_DATA_BOOTVERSION0_R2_LSB    _u(0)
#define OTP_DATA_BOOTVERSION0_R2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTVERSION1
// Description : Boot version thermometer counter, bits 47:24 (RBIT-3)
#define OTP_DATA_BOOTVERSION1_OFFSET _u(0x000000b6)
#define OTP_DATA_BOOTVERSION1_BITS   _u(0x00ffffff)
#define OTP_DATA_BOOTVERSION1_RESET  "-"
#define OTP_DATA_BOOTVERSION1_MSB    _u(23)
#define OTP_DATA_BOOTVERSION1_LSB    _u(0)
#define OTP_DATA_BOOTVERSION1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTVERSION1_R1
// Description : Redundant copy of BOOTVERSION1
#define OTP_DATA_BOOTVERSION1_R1_OFFSET _u(0x000000b8)
#define OTP_DATA_BOOTVERSION1_R1_BITS   _u(0x00ffffff)
#define OTP_DATA_BOOTVERSION1_R1_RESET  "-"
#define OTP_DATA_BOOTVERSION1_R1_MSB    _u(23)
#define OTP_DATA_BOOTVERSION1_R1_LSB    _u(0)
#define OTP_DATA_BOOTVERSION1_R1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOTVERSION1_R2
// Description : Redundant copy of BOOTVERSION1
#define OTP_DATA_BOOTVERSION1_R2_OFFSET _u(0x000000ba)
#define OTP_DATA_BOOTVERSION1_R2_BITS   _u(0x00ffffff)
#define OTP_DATA_BOOTVERSION1_R2_RESET  "-"
#define OTP_DATA_BOOTVERSION1_R2_MSB    _u(23)
#define OTP_DATA_BOOTVERSION1_R2_LSB    _u(0)
#define OTP_DATA_BOOTVERSION1_R2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOT_FLAGS
// Description : Disable/Enable boot paths/features in the RP2350 mask ROM.
//               Disables always supercede enables. Enables are provided where
//               there are other configurations in OTP that must be valid.
//               (RBIT-3)
#define OTP_DATA_BOOT_FLAGS_OFFSET _u(0x000000bc)
#define OTP_DATA_BOOT_FLAGS_BITS   _u(0x000007ff)
#define OTP_DATA_BOOT_FLAGS_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_ENABLE_UART_BOOT
// Description : None
#define OTP_DATA_BOOT_FLAGS_ENABLE_UART_BOOT_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_ENABLE_UART_BOOT_BITS   _u(0x00000400)
#define OTP_DATA_BOOT_FLAGS_ENABLE_UART_BOOT_MSB    _u(10)
#define OTP_DATA_BOOT_FLAGS_ENABLE_UART_BOOT_LSB    _u(10)
#define OTP_DATA_BOOT_FLAGS_ENABLE_UART_BOOT_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_ENABLE_I2C_BOOT
// Description : None
#define OTP_DATA_BOOT_FLAGS_ENABLE_I2C_BOOT_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_ENABLE_I2C_BOOT_BITS   _u(0x00000200)
#define OTP_DATA_BOOT_FLAGS_ENABLE_I2C_BOOT_MSB    _u(9)
#define OTP_DATA_BOOT_FLAGS_ENABLE_I2C_BOOT_LSB    _u(9)
#define OTP_DATA_BOOT_FLAGS_ENABLE_I2C_BOOT_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_ENABLE_OTP_BOOT
// Description : None
#define OTP_DATA_BOOT_FLAGS_ENABLE_OTP_BOOT_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_ENABLE_OTP_BOOT_BITS   _u(0x00000100)
#define OTP_DATA_BOOT_FLAGS_ENABLE_OTP_BOOT_MSB    _u(8)
#define OTP_DATA_BOOT_FLAGS_ENABLE_OTP_BOOT_LSB    _u(8)
#define OTP_DATA_BOOT_FLAGS_ENABLE_OTP_BOOT_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_DISABLE_FLASH_BOOT
// Description : None
#define OTP_DATA_BOOT_FLAGS_DISABLE_FLASH_BOOT_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_DISABLE_FLASH_BOOT_BITS   _u(0x00000080)
#define OTP_DATA_BOOT_FLAGS_DISABLE_FLASH_BOOT_MSB    _u(7)
#define OTP_DATA_BOOT_FLAGS_DISABLE_FLASH_BOOT_LSB    _u(7)
#define OTP_DATA_BOOT_FLAGS_DISABLE_FLASH_BOOT_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_DISABLE_UART_BOOT
// Description : None
#define OTP_DATA_BOOT_FLAGS_DISABLE_UART_BOOT_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_DISABLE_UART_BOOT_BITS   _u(0x00000040)
#define OTP_DATA_BOOT_FLAGS_DISABLE_UART_BOOT_MSB    _u(6)
#define OTP_DATA_BOOT_FLAGS_DISABLE_UART_BOOT_LSB    _u(6)
#define OTP_DATA_BOOT_FLAGS_DISABLE_UART_BOOT_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_DISABLE_I2C_BOOT
// Description : None
#define OTP_DATA_BOOT_FLAGS_DISABLE_I2C_BOOT_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_DISABLE_I2C_BOOT_BITS   _u(0x00000020)
#define OTP_DATA_BOOT_FLAGS_DISABLE_I2C_BOOT_MSB    _u(5)
#define OTP_DATA_BOOT_FLAGS_DISABLE_I2C_BOOT_LSB    _u(5)
#define OTP_DATA_BOOT_FLAGS_DISABLE_I2C_BOOT_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_DISABLE_WATCHDOG_SCRATCH
// Description : None
#define OTP_DATA_BOOT_FLAGS_DISABLE_WATCHDOG_SCRATCH_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_DISABLE_WATCHDOG_SCRATCH_BITS   _u(0x00000010)
#define OTP_DATA_BOOT_FLAGS_DISABLE_WATCHDOG_SCRATCH_MSB    _u(4)
#define OTP_DATA_BOOT_FLAGS_DISABLE_WATCHDOG_SCRATCH_LSB    _u(4)
#define OTP_DATA_BOOT_FLAGS_DISABLE_WATCHDOG_SCRATCH_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_DISABLE_POWER_SCRATCH
// Description : None
#define OTP_DATA_BOOT_FLAGS_DISABLE_POWER_SCRATCH_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_DISABLE_POWER_SCRATCH_BITS   _u(0x00000008)
#define OTP_DATA_BOOT_FLAGS_DISABLE_POWER_SCRATCH_MSB    _u(3)
#define OTP_DATA_BOOT_FLAGS_DISABLE_POWER_SCRATCH_LSB    _u(3)
#define OTP_DATA_BOOT_FLAGS_DISABLE_POWER_SCRATCH_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_DISABLE_OTP_BOOT
// Description : None
#define OTP_DATA_BOOT_FLAGS_DISABLE_OTP_BOOT_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_DISABLE_OTP_BOOT_BITS   _u(0x00000004)
#define OTP_DATA_BOOT_FLAGS_DISABLE_OTP_BOOT_MSB    _u(2)
#define OTP_DATA_BOOT_FLAGS_DISABLE_OTP_BOOT_LSB    _u(2)
#define OTP_DATA_BOOT_FLAGS_DISABLE_OTP_BOOT_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_DISABLE_USB_PICOBOOT_IFC
// Description : None
#define OTP_DATA_BOOT_FLAGS_DISABLE_USB_PICOBOOT_IFC_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_DISABLE_USB_PICOBOOT_IFC_BITS   _u(0x00000002)
#define OTP_DATA_BOOT_FLAGS_DISABLE_USB_PICOBOOT_IFC_MSB    _u(1)
#define OTP_DATA_BOOT_FLAGS_DISABLE_USB_PICOBOOT_IFC_LSB    _u(1)
#define OTP_DATA_BOOT_FLAGS_DISABLE_USB_PICOBOOT_IFC_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_FLAGS_DISABLE_USB_MSD_IFC
// Description : None
#define OTP_DATA_BOOT_FLAGS_DISABLE_USB_MSD_IFC_RESET  "-"
#define OTP_DATA_BOOT_FLAGS_DISABLE_USB_MSD_IFC_BITS   _u(0x00000001)
#define OTP_DATA_BOOT_FLAGS_DISABLE_USB_MSD_IFC_MSB    _u(0)
#define OTP_DATA_BOOT_FLAGS_DISABLE_USB_MSD_IFC_LSB    _u(0)
#define OTP_DATA_BOOT_FLAGS_DISABLE_USB_MSD_IFC_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOT_DISABLE_R1
// Description : Redundant copy of BOOT_DISABLE
#define OTP_DATA_BOOT_DISABLE_R1_OFFSET _u(0x000000be)
#define OTP_DATA_BOOT_DISABLE_R1_BITS   _u(0x00ffffff)
#define OTP_DATA_BOOT_DISABLE_R1_RESET  "-"
#define OTP_DATA_BOOT_DISABLE_R1_MSB    _u(23)
#define OTP_DATA_BOOT_DISABLE_R1_LSB    _u(0)
#define OTP_DATA_BOOT_DISABLE_R1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOT_DISABLE_R2
// Description : Redundant copy of BOOT_DISABLE
#define OTP_DATA_BOOT_DISABLE_R2_OFFSET _u(0x000000c0)
#define OTP_DATA_BOOT_DISABLE_R2_BITS   _u(0x00ffffff)
#define OTP_DATA_BOOT_DISABLE_R2_RESET  "-"
#define OTP_DATA_BOOT_DISABLE_R2_MSB    _u(23)
#define OTP_DATA_BOOT_DISABLE_R2_LSB    _u(0)
#define OTP_DATA_BOOT_DISABLE_R2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOT_LED_CFG
// Description : Pin configuration for LED status (used for anything in bootrom
//               that outputs to LED if enabled elsewhere
#define OTP_DATA_BOOT_LED_CFG_OFFSET _u(0x000000c2)
#define OTP_DATA_BOOT_LED_CFG_BITS   _u(0x000000ff)
#define OTP_DATA_BOOT_LED_CFG_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_LED_CFG_LED_PIN
// Description : GPIO index to use for bootloader activity LED.
#define OTP_DATA_BOOT_LED_CFG_LED_PIN_RESET  "-"
#define OTP_DATA_BOOT_LED_CFG_LED_PIN_BITS   _u(0x000000fc)
#define OTP_DATA_BOOT_LED_CFG_LED_PIN_MSB    _u(7)
#define OTP_DATA_BOOT_LED_CFG_LED_PIN_LSB    _u(2)
#define OTP_DATA_BOOT_LED_CFG_LED_PIN_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_LED_CFG_LED_ACTIVELOW
// Description : LED is active-low. (Default: active-high.)
#define OTP_DATA_BOOT_LED_CFG_LED_ACTIVELOW_RESET  "-"
#define OTP_DATA_BOOT_LED_CFG_LED_ACTIVELOW_BITS   _u(0x00000002)
#define OTP_DATA_BOOT_LED_CFG_LED_ACTIVELOW_MSB    _u(1)
#define OTP_DATA_BOOT_LED_CFG_LED_ACTIVELOW_LSB    _u(1)
#define OTP_DATA_BOOT_LED_CFG_LED_ACTIVELOW_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_LED_CFG_LED_VALID
// Description : Must be set to 1 for other LED configuration to be considered
//               valid
#define OTP_DATA_BOOT_LED_CFG_LED_VALID_RESET  "-"
#define OTP_DATA_BOOT_LED_CFG_LED_VALID_BITS   _u(0x00000001)
#define OTP_DATA_BOOT_LED_CFG_LED_VALID_MSB    _u(0)
#define OTP_DATA_BOOT_LED_CFG_LED_VALID_LSB    _u(0)
#define OTP_DATA_BOOT_LED_CFG_LED_VALID_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_LED_CFG_R1
// Description : Redundant copy of LED_CFG
#define OTP_DATA_LED_CFG_R1_OFFSET _u(0x000000c4)
#define OTP_DATA_LED_CFG_R1_BITS   _u(0x00ffffff)
#define OTP_DATA_LED_CFG_R1_RESET  "-"
#define OTP_DATA_LED_CFG_R1_MSB    _u(23)
#define OTP_DATA_LED_CFG_R1_LSB    _u(0)
#define OTP_DATA_LED_CFG_R1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_LED_CFG_R2
// Description : Redundant copy of LED_CFG
#define OTP_DATA_LED_CFG_R2_OFFSET _u(0x000000c6)
#define OTP_DATA_LED_CFG_R2_BITS   _u(0x00ffffff)
#define OTP_DATA_LED_CFG_R2_RESET  "-"
#define OTP_DATA_LED_CFG_R2_MSB    _u(23)
#define OTP_DATA_LED_CFG_R2_LSB    _u(0)
#define OTP_DATA_LED_CFG_R2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_CFG
// Description : BOOTSEL mode feature flags (USB boot and UART boot) (RBIT-3)
#define OTP_DATA_USBBOOT_CFG_OFFSET _u(0x000000c8)
#define OTP_DATA_USBBOOT_CFG_BITS   _u(0x001f3301)
#define OTP_DATA_USBBOOT_CFG_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING3
// Description : Enable override of String Index 3 (iSerial). See
//               USBBOOT_SDESCRIPTOR3_SRC.
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING3_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING3_BITS   _u(0x00100000)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING3_MSB    _u(20)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING3_LSB    _u(20)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING3_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING2
// Description : Enable override of String Index 2 (iProduct). See
//               USBBOOT_SDESCRIPTOR2_SRC.
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING2_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING2_BITS   _u(0x00080000)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING2_MSB    _u(19)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING2_LSB    _u(19)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING1
// Description : Enable override of String Index 1 (iManufacturer). See
//               USBBOOT_SDESCRIPTOR1_SRC.
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING1_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING1_BITS   _u(0x00040000)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING1_MSB    _u(18)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING1_LSB    _u(18)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING0
// Description : Enable override of String Index 0 (wLANGID). See
//               USBBOOT_SDESCRIPTOR0_SRC.
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING0_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING0_BITS   _u(0x00020000)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING0_MSB    _u(17)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING0_LSB    _u(17)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_STRING0_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_CFG_NONDEFAULT_DDESCRIPTOR
// Description : Enable replacing the USB boot Device Descriptor with a
//               user-provided one stored in OTP. See USBBOOT_DDESCRIPTOR_LEN
//               and USBBOOT_DDESCRIPTOR_SRC.
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_DDESCRIPTOR_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_DDESCRIPTOR_BITS   _u(0x00010000)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_DDESCRIPTOR_MSB    _u(16)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_DDESCRIPTOR_LSB    _u(16)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_DDESCRIPTOR_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_CFG_DOUBLE_TAP
// Description : Enable entering BOOTSEL mode via double-tap of the RUN/RSTn
//               pin. Adds a significant delay to boot time.
#define OTP_DATA_USBBOOT_CFG_DOUBLE_TAP_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_DOUBLE_TAP_BITS   _u(0x00002000)
#define OTP_DATA_USBBOOT_CFG_DOUBLE_TAP_MSB    _u(13)
#define OTP_DATA_USBBOOT_CFG_DOUBLE_TAP_LSB    _u(13)
#define OTP_DATA_USBBOOT_CFG_DOUBLE_TAP_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_CFG_DP_DM_SWAP
// Description : Swap DM/DP during USB boot, to support board layouts with
//               mirrored USB routing (deliberate or accidental).
#define OTP_DATA_USBBOOT_CFG_DP_DM_SWAP_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_DP_DM_SWAP_BITS   _u(0x00001000)
#define OTP_DATA_USBBOOT_CFG_DP_DM_SWAP_MSB    _u(12)
#define OTP_DATA_USBBOOT_CFG_DP_DM_SWAP_LSB    _u(12)
#define OTP_DATA_USBBOOT_CFG_DP_DM_SWAP_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_CFG_NONDEFAULT_ROSC_CFG
// Description : Use ROSC for BOOTSEL mode. Note ROSC should not be used for USB
//               boot, but is sufficient for UART boot. Ignored if
//               NONDEFAULT_PLL_XOSC_CFG is set.
//
//               Ensure that USBBOOT_ROSC_DIV, USBBOOT_ROSC_FREQA and
//               USBBOOT_ROSC_FREQB are correctly programmed before setting this
//               bit.
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_ROSC_CFG_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_ROSC_CFG_BITS   _u(0x00000200)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_ROSC_CFG_MSB    _u(9)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_ROSC_CFG_LSB    _u(9)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_ROSC_CFG_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_CFG_NONDEFAULT_PLL_XOSC_CFG
// Description : Enable loading of the nondefault XOSC and PLL configuration
//               before entering BOOTSEL mode.
//
//               Ensure that USBBOOT_XOSC_CFG and USBBOOT_PLL_CFG are correctly
//               programmed before setting this bit.
//
//               If this bit is set, user software may use the contents of
//               USBBOOT_PLL_CFG to calculated the expected ROSC frequency based
//               on the fixed USB boot frequency of 48 MHz.
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_PLL_XOSC_CFG_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_PLL_XOSC_CFG_BITS   _u(0x00000100)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_PLL_XOSC_CFG_MSB    _u(8)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_PLL_XOSC_CFG_LSB    _u(8)
#define OTP_DATA_USBBOOT_CFG_NONDEFAULT_PLL_XOSC_CFG_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_CFG_LED
// Description : Enable bootloader activity LED
#define OTP_DATA_USBBOOT_CFG_LED_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_LED_BITS   _u(0x00000001)
#define OTP_DATA_USBBOOT_CFG_LED_MSB    _u(0)
#define OTP_DATA_USBBOOT_CFG_LED_LSB    _u(0)
#define OTP_DATA_USBBOOT_CFG_LED_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_CFG_R1
// Description : Redundant copy of USBBOOT_CFG
#define OTP_DATA_USBBOOT_CFG_R1_OFFSET _u(0x000000ca)
#define OTP_DATA_USBBOOT_CFG_R1_BITS   _u(0x00ffffff)
#define OTP_DATA_USBBOOT_CFG_R1_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_R1_MSB    _u(23)
#define OTP_DATA_USBBOOT_CFG_R1_LSB    _u(0)
#define OTP_DATA_USBBOOT_CFG_R1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_CFG_R2
// Description : Redundant copy of USBBOOT_CFG
#define OTP_DATA_USBBOOT_CFG_R2_OFFSET _u(0x000000cc)
#define OTP_DATA_USBBOOT_CFG_R2_BITS   _u(0x00ffffff)
#define OTP_DATA_USBBOOT_CFG_R2_RESET  "-"
#define OTP_DATA_USBBOOT_CFG_R2_MSB    _u(23)
#define OTP_DATA_USBBOOT_CFG_R2_LSB    _u(0)
#define OTP_DATA_USBBOOT_CFG_R2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_PLL_CFG
// Description : Optional PLL configuration for BOOTSEL mode. (ECC)
//
//               This should be configured to produce an exact 48 MHz based on
//               the crystal oscillator frequency. User mode software may also
//               use this value to calculate the expected crystal frequency
//               based on an assumed 48 MHz PLL output.
//
//               If no configuration is given, the crystal is assumed to be 12
//               MHz.
//
//               The PLL frequency can be calculated as:
//
//               PLL out = (XOSC frequency / (REFDIV+1)) x FBDIV / (POSTDIV1 x
//               POSTDIV2)
//
//               Conversely the crystal frequency can be calculated as:
//
//               XOSC frequency = 48 MHz x (REFDIV+1) x (POSTDIV1 x POSTDIV2) /
//               FBDIV
//
//               (Note the  +1 on REFDIV is because the value stored in this OTP
//               location is the actual divisor value minus one.)
//
//               Valid if and only if USBBOOT_CFG_NONDEFAULT_CLOCK_CFG bit is
//               set. That bit should be set only after this row and
//               USBBOOT_XOSC_CFG are both correctly programmed.
#define OTP_DATA_USBBOOT_PLL_CFG_OFFSET _u(0x000000ce)
#define OTP_DATA_USBBOOT_PLL_CFG_BITS   _u(0x0000ffff)
#define OTP_DATA_USBBOOT_PLL_CFG_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_PLL_CFG_REFDIV
// Description : PLL reference divisor, minus one.
//
//               Programming a value of 0 means a reference divisor of 1.
//               Programming a value of 1 means a reference divisor of 2 (for
//               exceptionally fast XIN inputs)
#define OTP_DATA_USBBOOT_PLL_CFG_REFDIV_RESET  "-"
#define OTP_DATA_USBBOOT_PLL_CFG_REFDIV_BITS   _u(0x00008000)
#define OTP_DATA_USBBOOT_PLL_CFG_REFDIV_MSB    _u(15)
#define OTP_DATA_USBBOOT_PLL_CFG_REFDIV_LSB    _u(15)
#define OTP_DATA_USBBOOT_PLL_CFG_REFDIV_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_PLL_CFG_POSTDIV2
// Description : PLL post-divide 2 divisor, in the range 1..7 inclusive.
#define OTP_DATA_USBBOOT_PLL_CFG_POSTDIV2_RESET  "-"
#define OTP_DATA_USBBOOT_PLL_CFG_POSTDIV2_BITS   _u(0x00007000)
#define OTP_DATA_USBBOOT_PLL_CFG_POSTDIV2_MSB    _u(14)
#define OTP_DATA_USBBOOT_PLL_CFG_POSTDIV2_LSB    _u(12)
#define OTP_DATA_USBBOOT_PLL_CFG_POSTDIV2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_PLL_CFG_POSTDIV1
// Description : PLL post-divide 1 divisor, in the range 1..7 inclusive.
#define OTP_DATA_USBBOOT_PLL_CFG_POSTDIV1_RESET  "-"
#define OTP_DATA_USBBOOT_PLL_CFG_POSTDIV1_BITS   _u(0x00000e00)
#define OTP_DATA_USBBOOT_PLL_CFG_POSTDIV1_MSB    _u(11)
#define OTP_DATA_USBBOOT_PLL_CFG_POSTDIV1_LSB    _u(9)
#define OTP_DATA_USBBOOT_PLL_CFG_POSTDIV1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_PLL_CFG_FBDIV
// Description : PLL feedback divisor, in the range 16..320 inclusive.
#define OTP_DATA_USBBOOT_PLL_CFG_FBDIV_RESET  "-"
#define OTP_DATA_USBBOOT_PLL_CFG_FBDIV_BITS   _u(0x000001ff)
#define OTP_DATA_USBBOOT_PLL_CFG_FBDIV_MSB    _u(8)
#define OTP_DATA_USBBOOT_PLL_CFG_FBDIV_LSB    _u(0)
#define OTP_DATA_USBBOOT_PLL_CFG_FBDIV_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_XOSC_CFG
// Description : Nondefault crystal oscillator configuration for the USB
//               bootloader. (ECC)
//
//               These values may also be used by user code configuring the
//               crystal oscillator.
//
//               Valid if and only if USBBOOT_CFG_NONDEFAULT_CLOCK_CFG bit is
//               set. That bit should be set only after this row and
//               USBBOOT_PLL_CFG are both correctly programmed.
#define OTP_DATA_USBBOOT_XOSC_CFG_OFFSET _u(0x000000d0)
#define OTP_DATA_USBBOOT_XOSC_CFG_BITS   _u(0x0000ffff)
#define OTP_DATA_USBBOOT_XOSC_CFG_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_XOSC_CFG_RANGE
// Description : Value of the XOSC_CTRL_FREQ_RANGE register.
//               0x0 -> 1_15MHZ
//               0x1 -> 10_30MHZ
//               0x2 -> 25_60MHZ
//               0x3 -> 40_100MHZ
#define OTP_DATA_USBBOOT_XOSC_CFG_RANGE_RESET           "-"
#define OTP_DATA_USBBOOT_XOSC_CFG_RANGE_BITS            _u(0x0000c000)
#define OTP_DATA_USBBOOT_XOSC_CFG_RANGE_MSB             _u(15)
#define OTP_DATA_USBBOOT_XOSC_CFG_RANGE_LSB             _u(14)
#define OTP_DATA_USBBOOT_XOSC_CFG_RANGE_ACCESS          "RO"
#define OTP_DATA_USBBOOT_XOSC_CFG_RANGE_VALUE_1_15MHZ   _u(0x0)
#define OTP_DATA_USBBOOT_XOSC_CFG_RANGE_VALUE_10_30MHZ  _u(0x1)
#define OTP_DATA_USBBOOT_XOSC_CFG_RANGE_VALUE_25_60MHZ  _u(0x2)
#define OTP_DATA_USBBOOT_XOSC_CFG_RANGE_VALUE_40_100MHZ _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_XOSC_CFG_STARTUP
// Description : Value of the XOSC_STARTUP register
#define OTP_DATA_USBBOOT_XOSC_CFG_STARTUP_RESET  "-"
#define OTP_DATA_USBBOOT_XOSC_CFG_STARTUP_BITS   _u(0x00003fff)
#define OTP_DATA_USBBOOT_XOSC_CFG_STARTUP_MSB    _u(13)
#define OTP_DATA_USBBOOT_XOSC_CFG_STARTUP_LSB    _u(0)
#define OTP_DATA_USBBOOT_XOSC_CFG_STARTUP_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_ROSC_DIV
// Description : Divider and range settings for the ring oscillator used by
//               BOOTSEL mode. (ECC)
//
//               These fields correspond to the ROSC_CTRL_FREQ_RANGE and
//               ROSC_DIV register fields in the ROSC control registers.
//
//               Valid if and only if USBBOOT_CFG_NONDEFAULT_ROSC_CFG is set.
#define OTP_DATA_USBBOOT_ROSC_DIV_OFFSET _u(0x000000d2)
#define OTP_DATA_USBBOOT_ROSC_DIV_BITS   _u(0x000003ff)
#define OTP_DATA_USBBOOT_ROSC_DIV_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_ROSC_DIV_RANGE
// Description : 0x0 -> LOW
//               0x1 -> MEDIUM
//               0x3 -> HIGH
//               0x2 -> TOOHIGH
#define OTP_DATA_USBBOOT_ROSC_DIV_RANGE_RESET         "-"
#define OTP_DATA_USBBOOT_ROSC_DIV_RANGE_BITS          _u(0x00000300)
#define OTP_DATA_USBBOOT_ROSC_DIV_RANGE_MSB           _u(9)
#define OTP_DATA_USBBOOT_ROSC_DIV_RANGE_LSB           _u(8)
#define OTP_DATA_USBBOOT_ROSC_DIV_RANGE_ACCESS        "RO"
#define OTP_DATA_USBBOOT_ROSC_DIV_RANGE_VALUE_LOW     _u(0x0)
#define OTP_DATA_USBBOOT_ROSC_DIV_RANGE_VALUE_MEDIUM  _u(0x1)
#define OTP_DATA_USBBOOT_ROSC_DIV_RANGE_VALUE_HIGH    _u(0x3)
#define OTP_DATA_USBBOOT_ROSC_DIV_RANGE_VALUE_TOOHIGH _u(0x2)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_USBBOOT_ROSC_DIV_DIV
// Description : None
#define OTP_DATA_USBBOOT_ROSC_DIV_DIV_RESET  "-"
#define OTP_DATA_USBBOOT_ROSC_DIV_DIV_BITS   _u(0x000000ff)
#define OTP_DATA_USBBOOT_ROSC_DIV_DIV_MSB    _u(7)
#define OTP_DATA_USBBOOT_ROSC_DIV_DIV_LSB    _u(0)
#define OTP_DATA_USBBOOT_ROSC_DIV_DIV_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_ROSC_FREQA
// Description : FREQA settings for the ring oscillator, used by BOOTSEL mode.
//               (ECC)
//
//               Valid if and only if USBBOOT_CFG_NONDEFAULT_ROSC_CFG is set.
#define OTP_DATA_USBBOOT_ROSC_FREQA_OFFSET _u(0x000000d4)
#define OTP_DATA_USBBOOT_ROSC_FREQA_BITS   _u(0x0000ffff)
#define OTP_DATA_USBBOOT_ROSC_FREQA_RESET  "-"
#define OTP_DATA_USBBOOT_ROSC_FREQA_MSB    _u(15)
#define OTP_DATA_USBBOOT_ROSC_FREQA_LSB    _u(0)
#define OTP_DATA_USBBOOT_ROSC_FREQA_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_ROSC_FREQB
// Description : FREQB settings for the ring oscillator, used by BOOTSEL mode.
//               (ECC)
//
//               Valid if and only if USBBOOT_CFG_NONDEFAULT_ROSC_CFG is set.
#define OTP_DATA_USBBOOT_ROSC_FREQB_OFFSET _u(0x000000d6)
#define OTP_DATA_USBBOOT_ROSC_FREQB_BITS   _u(0x0000ffff)
#define OTP_DATA_USBBOOT_ROSC_FREQB_RESET  "-"
#define OTP_DATA_USBBOOT_ROSC_FREQB_MSB    _u(15)
#define OTP_DATA_USBBOOT_ROSC_FREQB_LSB    _u(0)
#define OTP_DATA_USBBOOT_ROSC_FREQB_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_DDESCRIPTOR_LEN
// Description : Length in bytes of a complete replacement USB Device Descriptor
//               used for USB boot mode. (ECC)
#define OTP_DATA_USBBOOT_DDESCRIPTOR_LEN_OFFSET _u(0x000000d8)
#define OTP_DATA_USBBOOT_DDESCRIPTOR_LEN_BITS   _u(0x0000ffff)
#define OTP_DATA_USBBOOT_DDESCRIPTOR_LEN_RESET  "-"
#define OTP_DATA_USBBOOT_DDESCRIPTOR_LEN_MSB    _u(15)
#define OTP_DATA_USBBOOT_DDESCRIPTOR_LEN_LSB    _u(0)
#define OTP_DATA_USBBOOT_DDESCRIPTOR_LEN_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_DDESCRIPTOR_SRC
// Description : Pointer to the replacement USB Device Descriptor for USB boot
//               mode. Note all descriptor contents should also be ECC (ECC)
#define OTP_DATA_USBBOOT_DDESCRIPTOR_SRC_OFFSET _u(0x000000da)
#define OTP_DATA_USBBOOT_DDESCRIPTOR_SRC_BITS   _u(0x0000ffff)
#define OTP_DATA_USBBOOT_DDESCRIPTOR_SRC_RESET  "-"
#define OTP_DATA_USBBOOT_DDESCRIPTOR_SRC_MSB    _u(15)
#define OTP_DATA_USBBOOT_DDESCRIPTOR_SRC_LSB    _u(0)
#define OTP_DATA_USBBOOT_DDESCRIPTOR_SRC_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_SDESCRIPTOR0_SRC
// Description : Pointer to the 0 terminated string replacement for index 0
//               (wLangId) for USB boot mode. Note string should also be ECC
//               (ECC)
#define OTP_DATA_USBBOOT_SDESCRIPTOR0_SRC_OFFSET _u(0x000000dc)
#define OTP_DATA_USBBOOT_SDESCRIPTOR0_SRC_BITS   _u(0x0000ffff)
#define OTP_DATA_USBBOOT_SDESCRIPTOR0_SRC_RESET  "-"
#define OTP_DATA_USBBOOT_SDESCRIPTOR0_SRC_MSB    _u(15)
#define OTP_DATA_USBBOOT_SDESCRIPTOR0_SRC_LSB    _u(0)
#define OTP_DATA_USBBOOT_SDESCRIPTOR0_SRC_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_SDESCRIPTOR1_SRC
// Description : Pointer to the 0 terminated string replacement for index 1
//               (iManufacturer) for USB boot mode. Note string should also be
//               ECC (ECC)
#define OTP_DATA_USBBOOT_SDESCRIPTOR1_SRC_OFFSET _u(0x000000de)
#define OTP_DATA_USBBOOT_SDESCRIPTOR1_SRC_BITS   _u(0x0000ffff)
#define OTP_DATA_USBBOOT_SDESCRIPTOR1_SRC_RESET  "-"
#define OTP_DATA_USBBOOT_SDESCRIPTOR1_SRC_MSB    _u(15)
#define OTP_DATA_USBBOOT_SDESCRIPTOR1_SRC_LSB    _u(0)
#define OTP_DATA_USBBOOT_SDESCRIPTOR1_SRC_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_SDESCRIPTOR2_SRC
// Description : Pointer to the 0 terminated string replacement for index 2
//               (iProduct) for USB boot mode.. Note string should also be ECC
//               (ECC)
#define OTP_DATA_USBBOOT_SDESCRIPTOR2_SRC_OFFSET _u(0x000000e0)
#define OTP_DATA_USBBOOT_SDESCRIPTOR2_SRC_BITS   _u(0x0000ffff)
#define OTP_DATA_USBBOOT_SDESCRIPTOR2_SRC_RESET  "-"
#define OTP_DATA_USBBOOT_SDESCRIPTOR2_SRC_MSB    _u(15)
#define OTP_DATA_USBBOOT_SDESCRIPTOR2_SRC_LSB    _u(0)
#define OTP_DATA_USBBOOT_SDESCRIPTOR2_SRC_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_SDESCRIPTOR3_SRC
// Description : Pointer to the 0 terminated string replacement for index 3
//               (iSeruak) for USB boot mode.. Note string should also be ECC
//               (ECC)
#define OTP_DATA_USBBOOT_SDESCRIPTOR3_SRC_OFFSET _u(0x000000e2)
#define OTP_DATA_USBBOOT_SDESCRIPTOR3_SRC_BITS   _u(0x0000ffff)
#define OTP_DATA_USBBOOT_SDESCRIPTOR3_SRC_RESET  "-"
#define OTP_DATA_USBBOOT_SDESCRIPTOR3_SRC_MSB    _u(15)
#define OTP_DATA_USBBOOT_SDESCRIPTOR3_SRC_LSB    _u(0)
#define OTP_DATA_USBBOOT_SDESCRIPTOR3_SRC_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_PICOBOOT_CFG
// Description : Extra configuration for the Picoboot interface (Details from
//               Graham at some point maybe)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_OFFSET _u(0x000000e4)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_BITS   _u(0x00ffffff)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_RESET  "-"
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_MSB    _u(23)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_LSB    _u(0)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_PICOBOOT_CFG_R1
// Description : Redundant copy of USBBOOT_PICOBOOT_CFG
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R1_OFFSET _u(0x000000e6)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R1_BITS   _u(0x00ffffff)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R1_RESET  "-"
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R1_MSB    _u(23)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R1_LSB    _u(0)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_USBBOOT_PICOBOOT_CFG_R2
// Description : Redundant copy of USBBOOT_PICOBOOT_CFG
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R2_OFFSET _u(0x000000e8)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R2_BITS   _u(0x00ffffff)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R2_RESET  "-"
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R2_MSB    _u(23)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R2_LSB    _u(0)
#define OTP_DATA_USBBOOT_PICOBOOT_CFG_R2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_OTPBOOT_SRC
// Description : OTP load offset (in bytes, though the lowest bit is ignored)
//               for the OTP boot image. (ECC)
//
//               If OTP boot is enabled, the bootrom will load from this
//               location into SRAM and then directly enter the loaded image.
//               Note that the image must be signed if SECURE_BOOT_ENABLE is
//               set. The image itself is assumed to be ECC-protected.
#define OTP_DATA_OTPBOOT_SRC_OFFSET _u(0x000000ea)
#define OTP_DATA_OTPBOOT_SRC_BITS   _u(0x0000ffff)
#define OTP_DATA_OTPBOOT_SRC_RESET  "-"
#define OTP_DATA_OTPBOOT_SRC_MSB    _u(15)
#define OTP_DATA_OTPBOOT_SRC_LSB    _u(0)
#define OTP_DATA_OTPBOOT_SRC_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_OTPBOOT_LEN
// Description : Length in bytes of the OTP boot image. (ECC)
#define OTP_DATA_OTPBOOT_LEN_OFFSET _u(0x000000ec)
#define OTP_DATA_OTPBOOT_LEN_BITS   _u(0x0000ffff)
#define OTP_DATA_OTPBOOT_LEN_RESET  "-"
#define OTP_DATA_OTPBOOT_LEN_MSB    _u(15)
#define OTP_DATA_OTPBOOT_LEN_LSB    _u(0)
#define OTP_DATA_OTPBOOT_LEN_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_OTPBOOT_DST0
// Description : Bits 15:0 of the OTP boot image load destination (and entry
//               point). (ECC)
//
//               Generally this should be a location in main SRAM. Must be at
//               least halfword-aligned.
#define OTP_DATA_OTPBOOT_DST0_OFFSET _u(0x000000ee)
#define OTP_DATA_OTPBOOT_DST0_BITS   _u(0x0000ffff)
#define OTP_DATA_OTPBOOT_DST0_RESET  "-"
#define OTP_DATA_OTPBOOT_DST0_MSB    _u(15)
#define OTP_DATA_OTPBOOT_DST0_LSB    _u(0)
#define OTP_DATA_OTPBOOT_DST0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_OTPBOOT_DST1
// Description : Bits 31:16 of the OTP boot image load destination (and entry
//               point). (ECC)
//
//               Must be at least halfword-aligned.
#define OTP_DATA_OTPBOOT_DST1_OFFSET _u(0x000000f0)
#define OTP_DATA_OTPBOOT_DST1_BITS   _u(0x0000ffff)
#define OTP_DATA_OTPBOOT_DST1_RESET  "-"
#define OTP_DATA_OTPBOOT_DST1_MSB    _u(15)
#define OTP_DATA_OTPBOOT_DST1_LSB    _u(0)
#define OTP_DATA_OTPBOOT_DST1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_UARTBOOT_BAUD
// Description : UART boot baud rate divided by 100. (ECC)
//
//               Note UART boot uses the USB clock setup to get a 48 MHz
//               reference.
#define OTP_DATA_UARTBOOT_BAUD_OFFSET _u(0x000000f2)
#define OTP_DATA_UARTBOOT_BAUD_BITS   _u(0x0000ffff)
#define OTP_DATA_UARTBOOT_BAUD_RESET  "-"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_UARTBOOT_BAUD_BAUD
// Description : None
#define OTP_DATA_UARTBOOT_BAUD_BAUD_RESET  "-"
#define OTP_DATA_UARTBOOT_BAUD_BAUD_BITS   _u(0x0000ffff)
#define OTP_DATA_UARTBOOT_BAUD_BAUD_MSB    _u(15)
#define OTP_DATA_UARTBOOT_BAUD_BAUD_LSB    _u(0)
#define OTP_DATA_UARTBOOT_BAUD_BAUD_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_UARTBOOT_PINS
// Description : UART boot pin configuration
#define OTP_DATA_UARTBOOT_PINS_OFFSET _u(0x000000f4)
#define OTP_DATA_UARTBOOT_PINS_BITS   _u(0x00003f3f)
#define OTP_DATA_UARTBOOT_PINS_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_UARTBOOT_PINS_PIN_RX
// Description : None
#define OTP_DATA_UARTBOOT_PINS_PIN_RX_RESET  "-"
#define OTP_DATA_UARTBOOT_PINS_PIN_RX_BITS   _u(0x00003f00)
#define OTP_DATA_UARTBOOT_PINS_PIN_RX_MSB    _u(13)
#define OTP_DATA_UARTBOOT_PINS_PIN_RX_LSB    _u(8)
#define OTP_DATA_UARTBOOT_PINS_PIN_RX_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_UARTBOOT_PINS_PIN_TX
// Description : None
#define OTP_DATA_UARTBOOT_PINS_PIN_TX_RESET  "-"
#define OTP_DATA_UARTBOOT_PINS_PIN_TX_BITS   _u(0x0000003f)
#define OTP_DATA_UARTBOOT_PINS_PIN_TX_MSB    _u(5)
#define OTP_DATA_UARTBOOT_PINS_PIN_TX_LSB    _u(0)
#define OTP_DATA_UARTBOOT_PINS_PIN_TX_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_I2CBOOT_PINS
// Description : None
#define OTP_DATA_I2CBOOT_PINS_OFFSET _u(0x000000f6)
#define OTP_DATA_I2CBOOT_PINS_BITS   _u(0x00003f3f)
#define OTP_DATA_I2CBOOT_PINS_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_I2CBOOT_PINS_PIN_SCK
// Description : None
#define OTP_DATA_I2CBOOT_PINS_PIN_SCK_RESET  "-"
#define OTP_DATA_I2CBOOT_PINS_PIN_SCK_BITS   _u(0x00003f00)
#define OTP_DATA_I2CBOOT_PINS_PIN_SCK_MSB    _u(13)
#define OTP_DATA_I2CBOOT_PINS_PIN_SCK_LSB    _u(8)
#define OTP_DATA_I2CBOOT_PINS_PIN_SCK_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_I2CBOOT_PINS_PIN_SDA
// Description : None
#define OTP_DATA_I2CBOOT_PINS_PIN_SDA_RESET  "-"
#define OTP_DATA_I2CBOOT_PINS_PIN_SDA_BITS   _u(0x0000003f)
#define OTP_DATA_I2CBOOT_PINS_PIN_SDA_MSB    _u(5)
#define OTP_DATA_I2CBOOT_PINS_PIN_SDA_LSB    _u(0)
#define OTP_DATA_I2CBOOT_PINS_PIN_SDA_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE2_WATERMARK
// Description : Generate an error if I try to put more than 128 bytes in page
//               1. TODO remove this.
#define OTP_DATA_PAGE2_WATERMARK_OFFSET _u(0x00000100)
#define OTP_DATA_PAGE2_WATERMARK_BITS   _u(0x0000ffff)
#define OTP_DATA_PAGE2_WATERMARK_RESET  "-"
#define OTP_DATA_PAGE2_WATERMARK_MSB    _u(15)
#define OTP_DATA_PAGE2_WATERMARK_LSB    _u(0)
#define OTP_DATA_PAGE2_WATERMARK_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN
// Description : bits to opt in behavior for A0 only
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_OFFSET _u(0x00000102)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_BITS   _u(0x00000fff)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_FASTER_SIGCHECK_ROSC_DIV
// Description : Enable quartering of ROSC divisor during signature check, to
//               reduce boot time
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_FASTER_SIGCHECK_ROSC_DIV_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_FASTER_SIGCHECK_ROSC_DIV_BITS   _u(0x00000800)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_FASTER_SIGCHECK_ROSC_DIV_MSB    _u(11)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_FASTER_SIGCHECK_ROSC_DIV_LSB    _u(11)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_FASTER_SIGCHECK_ROSC_DIV_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_PARTITION_FORWARDING_HACK
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_PARTITION_FORWARDING_HACK_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_PARTITION_FORWARDING_HACK_BITS   _u(0x00000400)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_PARTITION_FORWARDING_HACK_MSB    _u(10)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_PARTITION_FORWARDING_HACK_LSB    _u(10)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_PARTITION_FORWARDING_HACK_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_AUTO_SWITCH_CPU
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_AUTO_SWITCH_CPU_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_AUTO_SWITCH_CPU_BITS   _u(0x00000200)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_AUTO_SWITCH_CPU_MSB    _u(9)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_AUTO_SWITCH_CPU_LSB    _u(9)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_AUTO_SWITCH_CPU_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_BLOCK_BASED_BOOT
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_BLOCK_BASED_BOOT_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_BLOCK_BASED_BOOT_BITS   _u(0x00000100)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_BLOCK_BASED_BOOT_MSB    _u(8)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_BLOCK_BASED_BOOT_LSB    _u(8)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_BLOCK_BASED_BOOT_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USB_BOOT_LOCK_ADVANCE
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USB_BOOT_LOCK_ADVANCE_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USB_BOOT_LOCK_ADVANCE_BITS   _u(0x00000080)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USB_BOOT_LOCK_ADVANCE_MSB    _u(7)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USB_BOOT_LOCK_ADVANCE_LSB    _u(7)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USB_BOOT_LOCK_ADVANCE_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_DISABLE_RAM_ACCESS
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_DISABLE_RAM_ACCESS_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_DISABLE_RAM_ACCESS_BITS   _u(0x00000040)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_DISABLE_RAM_ACCESS_MSB    _u(6)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_DISABLE_RAM_ACCESS_LSB    _u(6)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_DISABLE_RAM_ACCESS_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_SAMPLE_COUN
//               T
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_SAMPLE_COUNT_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_SAMPLE_COUNT_BITS   _u(0x00000020)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_SAMPLE_COUNT_MSB    _u(5)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_SAMPLE_COUNT_LSB    _u(5)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_SAMPLE_COUNT_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_TRNG_CONFIG
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_TRNG_CONFIG_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_TRNG_CONFIG_BITS   _u(0x00000010)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_TRNG_CONFIG_MSB    _u(4)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_TRNG_CONFIG_LSB    _u(4)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_OVERRIDE_TRNG_CONFIG_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_VNC_BYPASS
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_VNC_BYPASS_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_VNC_BYPASS_BITS   _u(0x00000008)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_VNC_BYPASS_MSB    _u(3)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_VNC_BYPASS_LSB    _u(3)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_VNC_BYPASS_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_CRNGT_BYPASS
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_CRNGT_BYPASS_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_CRNGT_BYPASS_BITS   _u(0x00000004)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_CRNGT_BYPASS_MSB    _u(2)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_CRNGT_BYPASS_LSB    _u(2)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_CRNGT_BYPASS_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_AUTOCORRELAT
//               E_BYPASS
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_AUTOCORRELATE_BYPASS_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_AUTOCORRELATE_BYPASS_BITS   _u(0x00000002)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_AUTOCORRELATE_BYPASS_MSB    _u(1)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_AUTOCORRELATE_BYPASS_LSB    _u(1)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_TRNG_DISABLE_AUTOCORRELATE_BYPASS_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USE_TRNG
// Description : None
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USE_TRNG_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USE_TRNG_BITS   _u(0x00000001)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USE_TRNG_MSB    _u(0)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USE_TRNG_LSB    _u(0)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_USE_TRNG_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R1
// Description : Redundant copy of BOOT_TEMP_CHICKEN_BIT_OPT_IN
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R1_OFFSET _u(0x00000104)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R1_BITS   _u(0x00ffffff)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R1_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R1_MSB    _u(23)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R1_LSB    _u(0)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R2
// Description : Redundant copy of BOOT_TEMP_CHICKEN_BIT_OPT_IN
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R2_OFFSET _u(0x00000106)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R2_BITS   _u(0x00ffffff)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R2_RESET  "-"
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R2_MSB    _u(23)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R2_LSB    _u(0)
#define OTP_DATA_BOOT_TEMP_CHICKEN_BIT_OPT_IN_R2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_TRNG_CONFIG
// Description : Override value for trng_config if enabled
#define OTP_DATA_TRNG_CONFIG_OFFSET _u(0x00000108)
#define OTP_DATA_TRNG_CONFIG_BITS   _u(0x00000003)
#define OTP_DATA_TRNG_CONFIG_RESET  "-"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_TRNG_CONFIG_CONFIG
// Description : None
#define OTP_DATA_TRNG_CONFIG_CONFIG_RESET  "-"
#define OTP_DATA_TRNG_CONFIG_CONFIG_BITS   _u(0x00000003)
#define OTP_DATA_TRNG_CONFIG_CONFIG_MSB    _u(1)
#define OTP_DATA_TRNG_CONFIG_CONFIG_LSB    _u(0)
#define OTP_DATA_TRNG_CONFIG_CONFIG_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_TRNG_SAMPLE_COUNT
// Description : Override value for trng_sample_cnt1 if enabled
#define OTP_DATA_TRNG_SAMPLE_COUNT_OFFSET _u(0x0000010a)
#define OTP_DATA_TRNG_SAMPLE_COUNT_BITS   _u(0x0000ffff)
#define OTP_DATA_TRNG_SAMPLE_COUNT_RESET  "-"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_TRNG_SAMPLE_COUNT_COUNT
// Description : None
#define OTP_DATA_TRNG_SAMPLE_COUNT_COUNT_RESET  "-"
#define OTP_DATA_TRNG_SAMPLE_COUNT_COUNT_BITS   _u(0x0000ffff)
#define OTP_DATA_TRNG_SAMPLE_COUNT_COUNT_MSB    _u(15)
#define OTP_DATA_TRNG_SAMPLE_COUNT_COUNT_LSB    _u(0)
#define OTP_DATA_TRNG_SAMPLE_COUNT_COUNT_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY1_0
// Description : Bits 15:0 of key 1 (ECC)
#define OTP_DATA_KEY1_0_OFFSET _u(0x00001e90)
#define OTP_DATA_KEY1_0_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY1_0_RESET  "-"
#define OTP_DATA_KEY1_0_MSB    _u(15)
#define OTP_DATA_KEY1_0_LSB    _u(0)
#define OTP_DATA_KEY1_0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY1_1
// Description : Bits 31:16 of key 1 (ECC)
#define OTP_DATA_KEY1_1_OFFSET _u(0x00001e92)
#define OTP_DATA_KEY1_1_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY1_1_RESET  "-"
#define OTP_DATA_KEY1_1_MSB    _u(15)
#define OTP_DATA_KEY1_1_LSB    _u(0)
#define OTP_DATA_KEY1_1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY1_2
// Description : Bits 47:32 of key 1 (ECC)
#define OTP_DATA_KEY1_2_OFFSET _u(0x00001e94)
#define OTP_DATA_KEY1_2_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY1_2_RESET  "-"
#define OTP_DATA_KEY1_2_MSB    _u(15)
#define OTP_DATA_KEY1_2_LSB    _u(0)
#define OTP_DATA_KEY1_2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY1_3
// Description : Bits 63:48 of key 1 (ECC)
#define OTP_DATA_KEY1_3_OFFSET _u(0x00001e96)
#define OTP_DATA_KEY1_3_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY1_3_RESET  "-"
#define OTP_DATA_KEY1_3_MSB    _u(15)
#define OTP_DATA_KEY1_3_LSB    _u(0)
#define OTP_DATA_KEY1_3_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY1_4
// Description : Bits 79:64 of key 1 (ECC)
#define OTP_DATA_KEY1_4_OFFSET _u(0x00001e98)
#define OTP_DATA_KEY1_4_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY1_4_RESET  "-"
#define OTP_DATA_KEY1_4_MSB    _u(15)
#define OTP_DATA_KEY1_4_LSB    _u(0)
#define OTP_DATA_KEY1_4_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY1_5
// Description : Bits 95:80 of key 1 (ECC)
#define OTP_DATA_KEY1_5_OFFSET _u(0x00001e9a)
#define OTP_DATA_KEY1_5_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY1_5_RESET  "-"
#define OTP_DATA_KEY1_5_MSB    _u(15)
#define OTP_DATA_KEY1_5_LSB    _u(0)
#define OTP_DATA_KEY1_5_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY1_6
// Description : Bits 111:96 of key 1 (ECC)
#define OTP_DATA_KEY1_6_OFFSET _u(0x00001e9c)
#define OTP_DATA_KEY1_6_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY1_6_RESET  "-"
#define OTP_DATA_KEY1_6_MSB    _u(15)
#define OTP_DATA_KEY1_6_LSB    _u(0)
#define OTP_DATA_KEY1_6_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY1_7
// Description : Bits 127:112 of key 1 (ECC)
#define OTP_DATA_KEY1_7_OFFSET _u(0x00001e9e)
#define OTP_DATA_KEY1_7_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY1_7_RESET  "-"
#define OTP_DATA_KEY1_7_MSB    _u(15)
#define OTP_DATA_KEY1_7_LSB    _u(0)
#define OTP_DATA_KEY1_7_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY2_0
// Description : Bits 15:0 of key 2 (ECC)
#define OTP_DATA_KEY2_0_OFFSET _u(0x00001ea0)
#define OTP_DATA_KEY2_0_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY2_0_RESET  "-"
#define OTP_DATA_KEY2_0_MSB    _u(15)
#define OTP_DATA_KEY2_0_LSB    _u(0)
#define OTP_DATA_KEY2_0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY2_1
// Description : Bits 31:16 of key 2 (ECC)
#define OTP_DATA_KEY2_1_OFFSET _u(0x00001ea2)
#define OTP_DATA_KEY2_1_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY2_1_RESET  "-"
#define OTP_DATA_KEY2_1_MSB    _u(15)
#define OTP_DATA_KEY2_1_LSB    _u(0)
#define OTP_DATA_KEY2_1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY2_2
// Description : Bits 47:32 of key 2 (ECC)
#define OTP_DATA_KEY2_2_OFFSET _u(0x00001ea4)
#define OTP_DATA_KEY2_2_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY2_2_RESET  "-"
#define OTP_DATA_KEY2_2_MSB    _u(15)
#define OTP_DATA_KEY2_2_LSB    _u(0)
#define OTP_DATA_KEY2_2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY2_3
// Description : Bits 63:48 of key 2 (ECC)
#define OTP_DATA_KEY2_3_OFFSET _u(0x00001ea6)
#define OTP_DATA_KEY2_3_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY2_3_RESET  "-"
#define OTP_DATA_KEY2_3_MSB    _u(15)
#define OTP_DATA_KEY2_3_LSB    _u(0)
#define OTP_DATA_KEY2_3_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY2_4
// Description : Bits 79:64 of key 2 (ECC)
#define OTP_DATA_KEY2_4_OFFSET _u(0x00001ea8)
#define OTP_DATA_KEY2_4_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY2_4_RESET  "-"
#define OTP_DATA_KEY2_4_MSB    _u(15)
#define OTP_DATA_KEY2_4_LSB    _u(0)
#define OTP_DATA_KEY2_4_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY2_5
// Description : Bits 95:80 of key 2 (ECC)
#define OTP_DATA_KEY2_5_OFFSET _u(0x00001eaa)
#define OTP_DATA_KEY2_5_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY2_5_RESET  "-"
#define OTP_DATA_KEY2_5_MSB    _u(15)
#define OTP_DATA_KEY2_5_LSB    _u(0)
#define OTP_DATA_KEY2_5_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY2_6
// Description : Bits 111:96 of key 2 (ECC)
#define OTP_DATA_KEY2_6_OFFSET _u(0x00001eac)
#define OTP_DATA_KEY2_6_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY2_6_RESET  "-"
#define OTP_DATA_KEY2_6_MSB    _u(15)
#define OTP_DATA_KEY2_6_LSB    _u(0)
#define OTP_DATA_KEY2_6_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY2_7
// Description : Bits 127:112 of key 2 (ECC)
#define OTP_DATA_KEY2_7_OFFSET _u(0x00001eae)
#define OTP_DATA_KEY2_7_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY2_7_RESET  "-"
#define OTP_DATA_KEY2_7_MSB    _u(15)
#define OTP_DATA_KEY2_7_LSB    _u(0)
#define OTP_DATA_KEY2_7_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY3_0
// Description : Bits 15:0 of key 3 (ECC)
#define OTP_DATA_KEY3_0_OFFSET _u(0x00001eb0)
#define OTP_DATA_KEY3_0_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY3_0_RESET  "-"
#define OTP_DATA_KEY3_0_MSB    _u(15)
#define OTP_DATA_KEY3_0_LSB    _u(0)
#define OTP_DATA_KEY3_0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY3_1
// Description : Bits 31:16 of key 3 (ECC)
#define OTP_DATA_KEY3_1_OFFSET _u(0x00001eb2)
#define OTP_DATA_KEY3_1_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY3_1_RESET  "-"
#define OTP_DATA_KEY3_1_MSB    _u(15)
#define OTP_DATA_KEY3_1_LSB    _u(0)
#define OTP_DATA_KEY3_1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY3_2
// Description : Bits 47:32 of key 3 (ECC)
#define OTP_DATA_KEY3_2_OFFSET _u(0x00001eb4)
#define OTP_DATA_KEY3_2_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY3_2_RESET  "-"
#define OTP_DATA_KEY3_2_MSB    _u(15)
#define OTP_DATA_KEY3_2_LSB    _u(0)
#define OTP_DATA_KEY3_2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY3_3
// Description : Bits 63:48 of key 3 (ECC)
#define OTP_DATA_KEY3_3_OFFSET _u(0x00001eb6)
#define OTP_DATA_KEY3_3_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY3_3_RESET  "-"
#define OTP_DATA_KEY3_3_MSB    _u(15)
#define OTP_DATA_KEY3_3_LSB    _u(0)
#define OTP_DATA_KEY3_3_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY3_4
// Description : Bits 79:64 of key 3 (ECC)
#define OTP_DATA_KEY3_4_OFFSET _u(0x00001eb8)
#define OTP_DATA_KEY3_4_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY3_4_RESET  "-"
#define OTP_DATA_KEY3_4_MSB    _u(15)
#define OTP_DATA_KEY3_4_LSB    _u(0)
#define OTP_DATA_KEY3_4_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY3_5
// Description : Bits 95:80 of key 3 (ECC)
#define OTP_DATA_KEY3_5_OFFSET _u(0x00001eba)
#define OTP_DATA_KEY3_5_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY3_5_RESET  "-"
#define OTP_DATA_KEY3_5_MSB    _u(15)
#define OTP_DATA_KEY3_5_LSB    _u(0)
#define OTP_DATA_KEY3_5_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY3_6
// Description : Bits 111:96 of key 3 (ECC)
#define OTP_DATA_KEY3_6_OFFSET _u(0x00001ebc)
#define OTP_DATA_KEY3_6_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY3_6_RESET  "-"
#define OTP_DATA_KEY3_6_MSB    _u(15)
#define OTP_DATA_KEY3_6_LSB    _u(0)
#define OTP_DATA_KEY3_6_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY3_7
// Description : Bits 127:112 of key 3 (ECC)
#define OTP_DATA_KEY3_7_OFFSET _u(0x00001ebe)
#define OTP_DATA_KEY3_7_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY3_7_RESET  "-"
#define OTP_DATA_KEY3_7_MSB    _u(15)
#define OTP_DATA_KEY3_7_LSB    _u(0)
#define OTP_DATA_KEY3_7_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY4_0
// Description : Bits 15:0 of key 4 (ECC)
#define OTP_DATA_KEY4_0_OFFSET _u(0x00001ec0)
#define OTP_DATA_KEY4_0_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY4_0_RESET  "-"
#define OTP_DATA_KEY4_0_MSB    _u(15)
#define OTP_DATA_KEY4_0_LSB    _u(0)
#define OTP_DATA_KEY4_0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY4_1
// Description : Bits 31:16 of key 4 (ECC)
#define OTP_DATA_KEY4_1_OFFSET _u(0x00001ec2)
#define OTP_DATA_KEY4_1_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY4_1_RESET  "-"
#define OTP_DATA_KEY4_1_MSB    _u(15)
#define OTP_DATA_KEY4_1_LSB    _u(0)
#define OTP_DATA_KEY4_1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY4_2
// Description : Bits 47:32 of key 4 (ECC)
#define OTP_DATA_KEY4_2_OFFSET _u(0x00001ec4)
#define OTP_DATA_KEY4_2_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY4_2_RESET  "-"
#define OTP_DATA_KEY4_2_MSB    _u(15)
#define OTP_DATA_KEY4_2_LSB    _u(0)
#define OTP_DATA_KEY4_2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY4_3
// Description : Bits 63:48 of key 4 (ECC)
#define OTP_DATA_KEY4_3_OFFSET _u(0x00001ec6)
#define OTP_DATA_KEY4_3_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY4_3_RESET  "-"
#define OTP_DATA_KEY4_3_MSB    _u(15)
#define OTP_DATA_KEY4_3_LSB    _u(0)
#define OTP_DATA_KEY4_3_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY4_4
// Description : Bits 79:64 of key 4 (ECC)
#define OTP_DATA_KEY4_4_OFFSET _u(0x00001ec8)
#define OTP_DATA_KEY4_4_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY4_4_RESET  "-"
#define OTP_DATA_KEY4_4_MSB    _u(15)
#define OTP_DATA_KEY4_4_LSB    _u(0)
#define OTP_DATA_KEY4_4_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY4_5
// Description : Bits 95:80 of key 4 (ECC)
#define OTP_DATA_KEY4_5_OFFSET _u(0x00001eca)
#define OTP_DATA_KEY4_5_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY4_5_RESET  "-"
#define OTP_DATA_KEY4_5_MSB    _u(15)
#define OTP_DATA_KEY4_5_LSB    _u(0)
#define OTP_DATA_KEY4_5_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY4_6
// Description : Bits 111:96 of key 4 (ECC)
#define OTP_DATA_KEY4_6_OFFSET _u(0x00001ecc)
#define OTP_DATA_KEY4_6_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY4_6_RESET  "-"
#define OTP_DATA_KEY4_6_MSB    _u(15)
#define OTP_DATA_KEY4_6_LSB    _u(0)
#define OTP_DATA_KEY4_6_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY4_7
// Description : Bits 127:112 of key 4 (ECC)
#define OTP_DATA_KEY4_7_OFFSET _u(0x00001ece)
#define OTP_DATA_KEY4_7_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY4_7_RESET  "-"
#define OTP_DATA_KEY4_7_MSB    _u(15)
#define OTP_DATA_KEY4_7_LSB    _u(0)
#define OTP_DATA_KEY4_7_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY5_0
// Description : Bits 15:0 of key 5 (ECC)
#define OTP_DATA_KEY5_0_OFFSET _u(0x00001ed0)
#define OTP_DATA_KEY5_0_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY5_0_RESET  "-"
#define OTP_DATA_KEY5_0_MSB    _u(15)
#define OTP_DATA_KEY5_0_LSB    _u(0)
#define OTP_DATA_KEY5_0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY5_1
// Description : Bits 31:16 of key 5 (ECC)
#define OTP_DATA_KEY5_1_OFFSET _u(0x00001ed2)
#define OTP_DATA_KEY5_1_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY5_1_RESET  "-"
#define OTP_DATA_KEY5_1_MSB    _u(15)
#define OTP_DATA_KEY5_1_LSB    _u(0)
#define OTP_DATA_KEY5_1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY5_2
// Description : Bits 47:32 of key 5 (ECC)
#define OTP_DATA_KEY5_2_OFFSET _u(0x00001ed4)
#define OTP_DATA_KEY5_2_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY5_2_RESET  "-"
#define OTP_DATA_KEY5_2_MSB    _u(15)
#define OTP_DATA_KEY5_2_LSB    _u(0)
#define OTP_DATA_KEY5_2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY5_3
// Description : Bits 63:48 of key 5 (ECC)
#define OTP_DATA_KEY5_3_OFFSET _u(0x00001ed6)
#define OTP_DATA_KEY5_3_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY5_3_RESET  "-"
#define OTP_DATA_KEY5_3_MSB    _u(15)
#define OTP_DATA_KEY5_3_LSB    _u(0)
#define OTP_DATA_KEY5_3_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY5_4
// Description : Bits 79:64 of key 5 (ECC)
#define OTP_DATA_KEY5_4_OFFSET _u(0x00001ed8)
#define OTP_DATA_KEY5_4_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY5_4_RESET  "-"
#define OTP_DATA_KEY5_4_MSB    _u(15)
#define OTP_DATA_KEY5_4_LSB    _u(0)
#define OTP_DATA_KEY5_4_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY5_5
// Description : Bits 95:80 of key 5 (ECC)
#define OTP_DATA_KEY5_5_OFFSET _u(0x00001eda)
#define OTP_DATA_KEY5_5_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY5_5_RESET  "-"
#define OTP_DATA_KEY5_5_MSB    _u(15)
#define OTP_DATA_KEY5_5_LSB    _u(0)
#define OTP_DATA_KEY5_5_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY5_6
// Description : Bits 111:96 of key 5 (ECC)
#define OTP_DATA_KEY5_6_OFFSET _u(0x00001edc)
#define OTP_DATA_KEY5_6_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY5_6_RESET  "-"
#define OTP_DATA_KEY5_6_MSB    _u(15)
#define OTP_DATA_KEY5_6_LSB    _u(0)
#define OTP_DATA_KEY5_6_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY5_7
// Description : Bits 127:112 of key 5 (ECC)
#define OTP_DATA_KEY5_7_OFFSET _u(0x00001ede)
#define OTP_DATA_KEY5_7_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY5_7_RESET  "-"
#define OTP_DATA_KEY5_7_MSB    _u(15)
#define OTP_DATA_KEY5_7_LSB    _u(0)
#define OTP_DATA_KEY5_7_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY6_0
// Description : Bits 15:0 of key 6 (ECC)
#define OTP_DATA_KEY6_0_OFFSET _u(0x00001ee0)
#define OTP_DATA_KEY6_0_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY6_0_RESET  "-"
#define OTP_DATA_KEY6_0_MSB    _u(15)
#define OTP_DATA_KEY6_0_LSB    _u(0)
#define OTP_DATA_KEY6_0_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY6_1
// Description : Bits 31:16 of key 6 (ECC)
#define OTP_DATA_KEY6_1_OFFSET _u(0x00001ee2)
#define OTP_DATA_KEY6_1_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY6_1_RESET  "-"
#define OTP_DATA_KEY6_1_MSB    _u(15)
#define OTP_DATA_KEY6_1_LSB    _u(0)
#define OTP_DATA_KEY6_1_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY6_2
// Description : Bits 47:32 of key 6 (ECC)
#define OTP_DATA_KEY6_2_OFFSET _u(0x00001ee4)
#define OTP_DATA_KEY6_2_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY6_2_RESET  "-"
#define OTP_DATA_KEY6_2_MSB    _u(15)
#define OTP_DATA_KEY6_2_LSB    _u(0)
#define OTP_DATA_KEY6_2_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY6_3
// Description : Bits 63:48 of key 6 (ECC)
#define OTP_DATA_KEY6_3_OFFSET _u(0x00001ee6)
#define OTP_DATA_KEY6_3_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY6_3_RESET  "-"
#define OTP_DATA_KEY6_3_MSB    _u(15)
#define OTP_DATA_KEY6_3_LSB    _u(0)
#define OTP_DATA_KEY6_3_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY6_4
// Description : Bits 79:64 of key 6 (ECC)
#define OTP_DATA_KEY6_4_OFFSET _u(0x00001ee8)
#define OTP_DATA_KEY6_4_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY6_4_RESET  "-"
#define OTP_DATA_KEY6_4_MSB    _u(15)
#define OTP_DATA_KEY6_4_LSB    _u(0)
#define OTP_DATA_KEY6_4_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY6_5
// Description : Bits 95:80 of key 6 (ECC)
#define OTP_DATA_KEY6_5_OFFSET _u(0x00001eea)
#define OTP_DATA_KEY6_5_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY6_5_RESET  "-"
#define OTP_DATA_KEY6_5_MSB    _u(15)
#define OTP_DATA_KEY6_5_LSB    _u(0)
#define OTP_DATA_KEY6_5_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY6_6
// Description : Bits 111:96 of key 6 (ECC)
#define OTP_DATA_KEY6_6_OFFSET _u(0x00001eec)
#define OTP_DATA_KEY6_6_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY6_6_RESET  "-"
#define OTP_DATA_KEY6_6_MSB    _u(15)
#define OTP_DATA_KEY6_6_LSB    _u(0)
#define OTP_DATA_KEY6_6_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY6_7
// Description : Bits 127:112 of key 6 (ECC)
#define OTP_DATA_KEY6_7_OFFSET _u(0x00001eee)
#define OTP_DATA_KEY6_7_BITS   _u(0x0000ffff)
#define OTP_DATA_KEY6_7_RESET  "-"
#define OTP_DATA_KEY6_7_MSB    _u(15)
#define OTP_DATA_KEY6_7_LSB    _u(0)
#define OTP_DATA_KEY6_7_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY1_VALID
// Description : Valid flag for key 1. Once the valid flag is set, the key can
//               no longer be read or written, and becomes a valid fixed key for
//               protecting OTP pages.
#define OTP_DATA_KEY1_VALID_OFFSET _u(0x00001ef2)
#define OTP_DATA_KEY1_VALID_BITS   _u(0x00010101)
#define OTP_DATA_KEY1_VALID_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY1_VALID_VALID_R2
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY1_VALID_VALID_R2_RESET  "-"
#define OTP_DATA_KEY1_VALID_VALID_R2_BITS   _u(0x00010000)
#define OTP_DATA_KEY1_VALID_VALID_R2_MSB    _u(16)
#define OTP_DATA_KEY1_VALID_VALID_R2_LSB    _u(16)
#define OTP_DATA_KEY1_VALID_VALID_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY1_VALID_VALID_R1
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY1_VALID_VALID_R1_RESET  "-"
#define OTP_DATA_KEY1_VALID_VALID_R1_BITS   _u(0x00000100)
#define OTP_DATA_KEY1_VALID_VALID_R1_MSB    _u(8)
#define OTP_DATA_KEY1_VALID_VALID_R1_LSB    _u(8)
#define OTP_DATA_KEY1_VALID_VALID_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY1_VALID_VALID
// Description : None
#define OTP_DATA_KEY1_VALID_VALID_RESET  "-"
#define OTP_DATA_KEY1_VALID_VALID_BITS   _u(0x00000001)
#define OTP_DATA_KEY1_VALID_VALID_MSB    _u(0)
#define OTP_DATA_KEY1_VALID_VALID_LSB    _u(0)
#define OTP_DATA_KEY1_VALID_VALID_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY2_VALID
// Description : Valid flag for key 2. Once the valid flag is set, the key can
//               no longer be read or written, and becomes a valid fixed key for
//               protecting OTP pages.
#define OTP_DATA_KEY2_VALID_OFFSET _u(0x00001ef4)
#define OTP_DATA_KEY2_VALID_BITS   _u(0x00010101)
#define OTP_DATA_KEY2_VALID_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY2_VALID_VALID_R2
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY2_VALID_VALID_R2_RESET  "-"
#define OTP_DATA_KEY2_VALID_VALID_R2_BITS   _u(0x00010000)
#define OTP_DATA_KEY2_VALID_VALID_R2_MSB    _u(16)
#define OTP_DATA_KEY2_VALID_VALID_R2_LSB    _u(16)
#define OTP_DATA_KEY2_VALID_VALID_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY2_VALID_VALID_R1
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY2_VALID_VALID_R1_RESET  "-"
#define OTP_DATA_KEY2_VALID_VALID_R1_BITS   _u(0x00000100)
#define OTP_DATA_KEY2_VALID_VALID_R1_MSB    _u(8)
#define OTP_DATA_KEY2_VALID_VALID_R1_LSB    _u(8)
#define OTP_DATA_KEY2_VALID_VALID_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY2_VALID_VALID
// Description : None
#define OTP_DATA_KEY2_VALID_VALID_RESET  "-"
#define OTP_DATA_KEY2_VALID_VALID_BITS   _u(0x00000001)
#define OTP_DATA_KEY2_VALID_VALID_MSB    _u(0)
#define OTP_DATA_KEY2_VALID_VALID_LSB    _u(0)
#define OTP_DATA_KEY2_VALID_VALID_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY3_VALID
// Description : Valid flag for key 3. Once the valid flag is set, the key can
//               no longer be read or written, and becomes a valid fixed key for
//               protecting OTP pages.
#define OTP_DATA_KEY3_VALID_OFFSET _u(0x00001ef6)
#define OTP_DATA_KEY3_VALID_BITS   _u(0x00010101)
#define OTP_DATA_KEY3_VALID_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY3_VALID_VALID_R2
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY3_VALID_VALID_R2_RESET  "-"
#define OTP_DATA_KEY3_VALID_VALID_R2_BITS   _u(0x00010000)
#define OTP_DATA_KEY3_VALID_VALID_R2_MSB    _u(16)
#define OTP_DATA_KEY3_VALID_VALID_R2_LSB    _u(16)
#define OTP_DATA_KEY3_VALID_VALID_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY3_VALID_VALID_R1
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY3_VALID_VALID_R1_RESET  "-"
#define OTP_DATA_KEY3_VALID_VALID_R1_BITS   _u(0x00000100)
#define OTP_DATA_KEY3_VALID_VALID_R1_MSB    _u(8)
#define OTP_DATA_KEY3_VALID_VALID_R1_LSB    _u(8)
#define OTP_DATA_KEY3_VALID_VALID_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY3_VALID_VALID
// Description : None
#define OTP_DATA_KEY3_VALID_VALID_RESET  "-"
#define OTP_DATA_KEY3_VALID_VALID_BITS   _u(0x00000001)
#define OTP_DATA_KEY3_VALID_VALID_MSB    _u(0)
#define OTP_DATA_KEY3_VALID_VALID_LSB    _u(0)
#define OTP_DATA_KEY3_VALID_VALID_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY4_VALID
// Description : Valid flag for key 4. Once the valid flag is set, the key can
//               no longer be read or written, and becomes a valid fixed key for
//               protecting OTP pages.
#define OTP_DATA_KEY4_VALID_OFFSET _u(0x00001ef8)
#define OTP_DATA_KEY4_VALID_BITS   _u(0x00010101)
#define OTP_DATA_KEY4_VALID_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY4_VALID_VALID_R2
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY4_VALID_VALID_R2_RESET  "-"
#define OTP_DATA_KEY4_VALID_VALID_R2_BITS   _u(0x00010000)
#define OTP_DATA_KEY4_VALID_VALID_R2_MSB    _u(16)
#define OTP_DATA_KEY4_VALID_VALID_R2_LSB    _u(16)
#define OTP_DATA_KEY4_VALID_VALID_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY4_VALID_VALID_R1
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY4_VALID_VALID_R1_RESET  "-"
#define OTP_DATA_KEY4_VALID_VALID_R1_BITS   _u(0x00000100)
#define OTP_DATA_KEY4_VALID_VALID_R1_MSB    _u(8)
#define OTP_DATA_KEY4_VALID_VALID_R1_LSB    _u(8)
#define OTP_DATA_KEY4_VALID_VALID_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY4_VALID_VALID
// Description : None
#define OTP_DATA_KEY4_VALID_VALID_RESET  "-"
#define OTP_DATA_KEY4_VALID_VALID_BITS   _u(0x00000001)
#define OTP_DATA_KEY4_VALID_VALID_MSB    _u(0)
#define OTP_DATA_KEY4_VALID_VALID_LSB    _u(0)
#define OTP_DATA_KEY4_VALID_VALID_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY5_VALID
// Description : Valid flag for key 5. Once the valid flag is set, the key can
//               no longer be read or written, and becomes a valid fixed key for
//               protecting OTP pages.
#define OTP_DATA_KEY5_VALID_OFFSET _u(0x00001efa)
#define OTP_DATA_KEY5_VALID_BITS   _u(0x00010101)
#define OTP_DATA_KEY5_VALID_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY5_VALID_VALID_R2
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY5_VALID_VALID_R2_RESET  "-"
#define OTP_DATA_KEY5_VALID_VALID_R2_BITS   _u(0x00010000)
#define OTP_DATA_KEY5_VALID_VALID_R2_MSB    _u(16)
#define OTP_DATA_KEY5_VALID_VALID_R2_LSB    _u(16)
#define OTP_DATA_KEY5_VALID_VALID_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY5_VALID_VALID_R1
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY5_VALID_VALID_R1_RESET  "-"
#define OTP_DATA_KEY5_VALID_VALID_R1_BITS   _u(0x00000100)
#define OTP_DATA_KEY5_VALID_VALID_R1_MSB    _u(8)
#define OTP_DATA_KEY5_VALID_VALID_R1_LSB    _u(8)
#define OTP_DATA_KEY5_VALID_VALID_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY5_VALID_VALID
// Description : None
#define OTP_DATA_KEY5_VALID_VALID_RESET  "-"
#define OTP_DATA_KEY5_VALID_VALID_BITS   _u(0x00000001)
#define OTP_DATA_KEY5_VALID_VALID_MSB    _u(0)
#define OTP_DATA_KEY5_VALID_VALID_LSB    _u(0)
#define OTP_DATA_KEY5_VALID_VALID_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_KEY6_VALID
// Description : Valid flag for key 6. Once the valid flag is set, the key can
//               no longer be read or written, and becomes a valid fixed key for
//               protecting OTP pages.
#define OTP_DATA_KEY6_VALID_OFFSET _u(0x00001efc)
#define OTP_DATA_KEY6_VALID_BITS   _u(0x00010101)
#define OTP_DATA_KEY6_VALID_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY6_VALID_VALID_R2
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY6_VALID_VALID_R2_RESET  "-"
#define OTP_DATA_KEY6_VALID_VALID_R2_BITS   _u(0x00010000)
#define OTP_DATA_KEY6_VALID_VALID_R2_MSB    _u(16)
#define OTP_DATA_KEY6_VALID_VALID_R2_LSB    _u(16)
#define OTP_DATA_KEY6_VALID_VALID_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY6_VALID_VALID_R1
// Description : Redundant copy of VALID, with 3-way majority vote
#define OTP_DATA_KEY6_VALID_VALID_R1_RESET  "-"
#define OTP_DATA_KEY6_VALID_VALID_R1_BITS   _u(0x00000100)
#define OTP_DATA_KEY6_VALID_VALID_R1_MSB    _u(8)
#define OTP_DATA_KEY6_VALID_VALID_R1_LSB    _u(8)
#define OTP_DATA_KEY6_VALID_VALID_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_KEY6_VALID_VALID
// Description : None
#define OTP_DATA_KEY6_VALID_VALID_RESET  "-"
#define OTP_DATA_KEY6_VALID_VALID_BITS   _u(0x00000001)
#define OTP_DATA_KEY6_VALID_VALID_MSB    _u(0)
#define OTP_DATA_KEY6_VALID_VALID_LSB    _u(0)
#define OTP_DATA_KEY6_VALID_VALID_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE0_LOCK0
// Description : Lock configuration LSBs for page 0 (addresses 0x0 through
//               0x7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE0_LOCK0_OFFSET _u(0x00001f00)
#define OTP_DATA_PAGE0_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE0_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE0_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE0_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE0_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE0_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE0_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE0_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE0_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE0_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE0_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE0_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE0_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE0_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE0_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE0_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE0_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE0_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE0_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE0_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE0_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE0_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE0_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE0_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE0_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE0_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE0_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE0_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE0_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE0_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE0_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE0_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE0_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE0_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE0_LOCK1
// Description : Lock configuration MSBs for page 0 (addresses 0x0 through
//               0x7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE0_LOCK1_OFFSET _u(0x00001f02)
#define OTP_DATA_PAGE0_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE0_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE0_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE0_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE0_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE0_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE0_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE0_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE0_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE0_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE0_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE0_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE0_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE0_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE0_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE0_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE0_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE0_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE0_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE0_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE0_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE0_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE0_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE0_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE0_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE0_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE0_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE0_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE0_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE0_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE0_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE0_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE0_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE0_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE0_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE0_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE0_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE0_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE0_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE0_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE0_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE0_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE0_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE0_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE1_LOCK0
// Description : Lock configuration LSBs for page 1 (addresses 0x80 through
//               0xff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE1_LOCK0_OFFSET _u(0x00001f04)
#define OTP_DATA_PAGE1_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE1_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE1_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE1_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE1_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE1_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE1_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE1_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE1_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE1_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE1_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE1_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE1_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE1_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE1_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE1_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE1_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE1_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE1_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE1_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE1_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE1_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE1_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE1_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE1_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE1_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE1_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE1_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE1_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE1_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE1_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE1_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE1_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE1_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE1_LOCK1
// Description : Lock configuration MSBs for page 1 (addresses 0x80 through
//               0xff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE1_LOCK1_OFFSET _u(0x00001f06)
#define OTP_DATA_PAGE1_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE1_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE1_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE1_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE1_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE1_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE1_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE1_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE1_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE1_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE1_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE1_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE1_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE1_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE1_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE1_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE1_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE1_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE1_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE1_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE1_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE1_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE1_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE1_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE1_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE1_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE1_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE1_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE1_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE1_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE1_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE1_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE1_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE1_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE1_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE1_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE1_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE1_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE1_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE1_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE1_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE1_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE1_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE1_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE2_LOCK0
// Description : Lock configuration LSBs for page 2 (addresses 0x100 through
//               0x17f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE2_LOCK0_OFFSET _u(0x00001f08)
#define OTP_DATA_PAGE2_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE2_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE2_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE2_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE2_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE2_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE2_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE2_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE2_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE2_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE2_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE2_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE2_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE2_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE2_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE2_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE2_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE2_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE2_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE2_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE2_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE2_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE2_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE2_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE2_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE2_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE2_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE2_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE2_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE2_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE2_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE2_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE2_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE2_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE2_LOCK1
// Description : Lock configuration MSBs for page 2 (addresses 0x100 through
//               0x17f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE2_LOCK1_OFFSET _u(0x00001f0a)
#define OTP_DATA_PAGE2_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE2_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE2_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE2_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE2_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE2_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE2_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE2_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE2_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE2_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE2_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE2_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE2_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE2_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE2_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE2_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE2_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE2_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE2_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE2_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE2_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE2_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE2_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE2_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE2_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE2_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE2_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE2_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE2_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE2_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE2_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE2_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE2_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE2_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE2_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE2_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE2_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE2_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE2_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE2_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE2_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE2_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE2_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE2_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE3_LOCK0
// Description : Lock configuration LSBs for page 3 (addresses 0x180 through
//               0x1ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE3_LOCK0_OFFSET _u(0x00001f0c)
#define OTP_DATA_PAGE3_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE3_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE3_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE3_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE3_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE3_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE3_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE3_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE3_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE3_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE3_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE3_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE3_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE3_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE3_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE3_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE3_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE3_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE3_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE3_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE3_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE3_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE3_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE3_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE3_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE3_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE3_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE3_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE3_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE3_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE3_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE3_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE3_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE3_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE3_LOCK1
// Description : Lock configuration MSBs for page 3 (addresses 0x180 through
//               0x1ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE3_LOCK1_OFFSET _u(0x00001f0e)
#define OTP_DATA_PAGE3_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE3_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE3_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE3_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE3_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE3_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE3_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE3_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE3_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE3_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE3_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE3_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE3_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE3_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE3_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE3_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE3_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE3_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE3_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE3_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE3_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE3_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE3_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE3_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE3_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE3_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE3_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE3_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE3_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE3_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE3_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE3_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE3_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE3_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE3_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE3_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE3_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE3_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE3_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE3_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE3_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE3_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE3_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE3_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE4_LOCK0
// Description : Lock configuration LSBs for page 4 (addresses 0x200 through
//               0x27f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE4_LOCK0_OFFSET _u(0x00001f10)
#define OTP_DATA_PAGE4_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE4_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE4_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE4_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE4_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE4_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE4_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE4_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE4_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE4_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE4_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE4_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE4_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE4_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE4_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE4_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE4_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE4_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE4_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE4_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE4_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE4_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE4_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE4_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE4_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE4_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE4_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE4_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE4_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE4_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE4_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE4_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE4_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE4_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE4_LOCK1
// Description : Lock configuration MSBs for page 4 (addresses 0x200 through
//               0x27f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE4_LOCK1_OFFSET _u(0x00001f12)
#define OTP_DATA_PAGE4_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE4_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE4_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE4_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE4_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE4_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE4_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE4_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE4_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE4_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE4_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE4_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE4_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE4_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE4_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE4_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE4_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE4_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE4_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE4_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE4_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE4_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE4_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE4_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE4_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE4_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE4_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE4_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE4_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE4_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE4_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE4_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE4_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE4_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE4_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE4_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE4_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE4_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE4_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE4_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE4_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE4_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE4_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE4_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE5_LOCK0
// Description : Lock configuration LSBs for page 5 (addresses 0x280 through
//               0x2ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE5_LOCK0_OFFSET _u(0x00001f14)
#define OTP_DATA_PAGE5_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE5_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE5_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE5_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE5_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE5_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE5_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE5_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE5_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE5_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE5_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE5_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE5_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE5_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE5_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE5_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE5_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE5_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE5_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE5_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE5_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE5_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE5_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE5_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE5_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE5_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE5_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE5_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE5_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE5_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE5_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE5_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE5_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE5_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE5_LOCK1
// Description : Lock configuration MSBs for page 5 (addresses 0x280 through
//               0x2ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE5_LOCK1_OFFSET _u(0x00001f16)
#define OTP_DATA_PAGE5_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE5_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE5_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE5_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE5_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE5_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE5_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE5_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE5_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE5_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE5_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE5_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE5_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE5_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE5_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE5_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE5_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE5_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE5_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE5_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE5_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE5_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE5_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE5_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE5_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE5_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE5_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE5_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE5_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE5_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE5_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE5_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE5_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE5_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE5_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE5_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE5_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE5_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE5_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE5_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE5_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE5_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE5_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE5_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE6_LOCK0
// Description : Lock configuration LSBs for page 6 (addresses 0x300 through
//               0x37f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE6_LOCK0_OFFSET _u(0x00001f18)
#define OTP_DATA_PAGE6_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE6_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE6_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE6_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE6_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE6_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE6_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE6_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE6_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE6_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE6_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE6_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE6_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE6_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE6_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE6_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE6_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE6_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE6_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE6_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE6_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE6_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE6_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE6_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE6_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE6_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE6_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE6_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE6_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE6_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE6_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE6_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE6_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE6_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE6_LOCK1
// Description : Lock configuration MSBs for page 6 (addresses 0x300 through
//               0x37f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE6_LOCK1_OFFSET _u(0x00001f1a)
#define OTP_DATA_PAGE6_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE6_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE6_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE6_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE6_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE6_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE6_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE6_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE6_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE6_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE6_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE6_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE6_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE6_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE6_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE6_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE6_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE6_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE6_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE6_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE6_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE6_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE6_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE6_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE6_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE6_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE6_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE6_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE6_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE6_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE6_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE6_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE6_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE6_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE6_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE6_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE6_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE6_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE6_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE6_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE6_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE6_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE6_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE6_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE7_LOCK0
// Description : Lock configuration LSBs for page 7 (addresses 0x380 through
//               0x3ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE7_LOCK0_OFFSET _u(0x00001f1c)
#define OTP_DATA_PAGE7_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE7_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE7_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE7_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE7_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE7_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE7_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE7_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE7_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE7_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE7_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE7_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE7_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE7_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE7_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE7_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE7_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE7_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE7_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE7_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE7_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE7_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE7_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE7_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE7_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE7_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE7_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE7_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE7_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE7_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE7_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE7_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE7_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE7_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE7_LOCK1
// Description : Lock configuration MSBs for page 7 (addresses 0x380 through
//               0x3ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE7_LOCK1_OFFSET _u(0x00001f1e)
#define OTP_DATA_PAGE7_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE7_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE7_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE7_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE7_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE7_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE7_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE7_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE7_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE7_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE7_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE7_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE7_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE7_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE7_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE7_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE7_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE7_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE7_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE7_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE7_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE7_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE7_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE7_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE7_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE7_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE7_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE7_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE7_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE7_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE7_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE7_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE7_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE7_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE7_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE7_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE7_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE7_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE7_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE7_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE7_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE7_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE7_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE7_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE8_LOCK0
// Description : Lock configuration LSBs for page 8 (addresses 0x400 through
//               0x47f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE8_LOCK0_OFFSET _u(0x00001f20)
#define OTP_DATA_PAGE8_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE8_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE8_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE8_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE8_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE8_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE8_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE8_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE8_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE8_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE8_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE8_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE8_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE8_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE8_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE8_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE8_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE8_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE8_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE8_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE8_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE8_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE8_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE8_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE8_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE8_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE8_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE8_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE8_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE8_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE8_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE8_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE8_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE8_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE8_LOCK1
// Description : Lock configuration MSBs for page 8 (addresses 0x400 through
//               0x47f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE8_LOCK1_OFFSET _u(0x00001f22)
#define OTP_DATA_PAGE8_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE8_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE8_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE8_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE8_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE8_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE8_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE8_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE8_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE8_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE8_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE8_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE8_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE8_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE8_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE8_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE8_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE8_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE8_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE8_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE8_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE8_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE8_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE8_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE8_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE8_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE8_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE8_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE8_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE8_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE8_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE8_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE8_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE8_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE8_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE8_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE8_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE8_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE8_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE8_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE8_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE8_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE8_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE8_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE9_LOCK0
// Description : Lock configuration LSBs for page 9 (addresses 0x480 through
//               0x4ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE9_LOCK0_OFFSET _u(0x00001f24)
#define OTP_DATA_PAGE9_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE9_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE9_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE9_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE9_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE9_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE9_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE9_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE9_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE9_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE9_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE9_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE9_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE9_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE9_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE9_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE9_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE9_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE9_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE9_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE9_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE9_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE9_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE9_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE9_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE9_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE9_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE9_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE9_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE9_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE9_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE9_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE9_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE9_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE9_LOCK1
// Description : Lock configuration MSBs for page 9 (addresses 0x480 through
//               0x4ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE9_LOCK1_OFFSET _u(0x00001f26)
#define OTP_DATA_PAGE9_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE9_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE9_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE9_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE9_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE9_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE9_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE9_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE9_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE9_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE9_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE9_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE9_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE9_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE9_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE9_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE9_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE9_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE9_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE9_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE9_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE9_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE9_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE9_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE9_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE9_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE9_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE9_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE9_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE9_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE9_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE9_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE9_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE9_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE9_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE9_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE9_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE9_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE9_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE9_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE9_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE9_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE9_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE9_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE10_LOCK0
// Description : Lock configuration LSBs for page 10 (addresses 0x500 through
//               0x57f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE10_LOCK0_OFFSET _u(0x00001f28)
#define OTP_DATA_PAGE10_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE10_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE10_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE10_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE10_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE10_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE10_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE10_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE10_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE10_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE10_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE10_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE10_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE10_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE10_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE10_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE10_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE10_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE10_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE10_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE10_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE10_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE10_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE10_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE10_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE10_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE10_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE10_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE10_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE10_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE10_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE10_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE10_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE10_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE10_LOCK1
// Description : Lock configuration MSBs for page 10 (addresses 0x500 through
//               0x57f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE10_LOCK1_OFFSET _u(0x00001f2a)
#define OTP_DATA_PAGE10_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE10_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE10_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE10_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE10_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE10_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE10_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE10_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE10_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE10_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE10_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE10_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE10_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE10_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE10_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE10_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE10_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE10_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE10_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE10_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE10_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE10_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE10_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE10_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE10_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE10_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE10_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE10_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE10_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE10_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE10_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE10_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE10_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE10_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE10_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE10_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE10_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE10_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE10_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE10_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE10_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE10_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE10_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE10_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE11_LOCK0
// Description : Lock configuration LSBs for page 11 (addresses 0x580 through
//               0x5ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE11_LOCK0_OFFSET _u(0x00001f2c)
#define OTP_DATA_PAGE11_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE11_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE11_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE11_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE11_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE11_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE11_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE11_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE11_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE11_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE11_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE11_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE11_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE11_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE11_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE11_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE11_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE11_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE11_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE11_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE11_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE11_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE11_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE11_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE11_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE11_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE11_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE11_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE11_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE11_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE11_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE11_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE11_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE11_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE11_LOCK1
// Description : Lock configuration MSBs for page 11 (addresses 0x580 through
//               0x5ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE11_LOCK1_OFFSET _u(0x00001f2e)
#define OTP_DATA_PAGE11_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE11_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE11_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE11_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE11_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE11_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE11_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE11_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE11_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE11_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE11_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE11_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE11_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE11_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE11_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE11_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE11_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE11_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE11_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE11_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE11_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE11_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE11_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE11_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE11_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE11_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE11_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE11_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE11_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE11_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE11_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE11_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE11_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE11_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE11_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE11_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE11_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE11_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE11_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE11_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE11_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE11_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE11_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE11_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE12_LOCK0
// Description : Lock configuration LSBs for page 12 (addresses 0x600 through
//               0x67f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE12_LOCK0_OFFSET _u(0x00001f30)
#define OTP_DATA_PAGE12_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE12_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE12_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE12_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE12_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE12_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE12_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE12_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE12_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE12_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE12_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE12_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE12_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE12_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE12_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE12_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE12_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE12_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE12_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE12_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE12_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE12_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE12_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE12_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE12_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE12_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE12_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE12_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE12_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE12_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE12_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE12_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE12_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE12_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE12_LOCK1
// Description : Lock configuration MSBs for page 12 (addresses 0x600 through
//               0x67f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE12_LOCK1_OFFSET _u(0x00001f32)
#define OTP_DATA_PAGE12_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE12_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE12_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE12_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE12_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE12_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE12_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE12_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE12_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE12_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE12_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE12_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE12_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE12_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE12_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE12_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE12_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE12_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE12_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE12_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE12_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE12_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE12_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE12_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE12_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE12_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE12_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE12_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE12_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE12_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE12_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE12_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE12_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE12_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE12_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE12_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE12_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE12_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE12_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE12_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE12_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE12_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE12_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE12_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE13_LOCK0
// Description : Lock configuration LSBs for page 13 (addresses 0x680 through
//               0x6ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE13_LOCK0_OFFSET _u(0x00001f34)
#define OTP_DATA_PAGE13_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE13_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE13_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE13_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE13_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE13_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE13_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE13_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE13_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE13_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE13_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE13_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE13_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE13_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE13_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE13_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE13_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE13_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE13_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE13_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE13_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE13_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE13_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE13_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE13_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE13_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE13_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE13_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE13_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE13_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE13_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE13_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE13_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE13_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE13_LOCK1
// Description : Lock configuration MSBs for page 13 (addresses 0x680 through
//               0x6ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE13_LOCK1_OFFSET _u(0x00001f36)
#define OTP_DATA_PAGE13_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE13_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE13_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE13_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE13_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE13_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE13_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE13_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE13_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE13_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE13_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE13_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE13_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE13_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE13_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE13_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE13_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE13_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE13_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE13_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE13_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE13_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE13_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE13_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE13_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE13_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE13_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE13_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE13_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE13_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE13_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE13_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE13_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE13_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE13_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE13_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE13_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE13_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE13_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE13_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE13_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE13_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE13_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE13_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE14_LOCK0
// Description : Lock configuration LSBs for page 14 (addresses 0x700 through
//               0x77f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE14_LOCK0_OFFSET _u(0x00001f38)
#define OTP_DATA_PAGE14_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE14_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE14_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE14_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE14_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE14_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE14_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE14_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE14_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE14_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE14_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE14_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE14_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE14_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE14_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE14_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE14_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE14_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE14_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE14_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE14_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE14_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE14_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE14_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE14_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE14_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE14_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE14_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE14_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE14_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE14_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE14_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE14_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE14_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE14_LOCK1
// Description : Lock configuration MSBs for page 14 (addresses 0x700 through
//               0x77f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE14_LOCK1_OFFSET _u(0x00001f3a)
#define OTP_DATA_PAGE14_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE14_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE14_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE14_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE14_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE14_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE14_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE14_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE14_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE14_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE14_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE14_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE14_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE14_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE14_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE14_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE14_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE14_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE14_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE14_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE14_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE14_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE14_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE14_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE14_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE14_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE14_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE14_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE14_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE14_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE14_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE14_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE14_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE14_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE14_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE14_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE14_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE14_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE14_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE14_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE14_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE14_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE14_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE14_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE15_LOCK0
// Description : Lock configuration LSBs for page 15 (addresses 0x780 through
//               0x7ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE15_LOCK0_OFFSET _u(0x00001f3c)
#define OTP_DATA_PAGE15_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE15_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE15_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE15_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE15_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE15_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE15_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE15_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE15_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE15_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE15_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE15_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE15_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE15_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE15_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE15_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE15_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE15_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE15_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE15_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE15_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE15_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE15_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE15_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE15_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE15_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE15_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE15_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE15_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE15_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE15_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE15_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE15_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE15_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE15_LOCK1
// Description : Lock configuration MSBs for page 15 (addresses 0x780 through
//               0x7ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE15_LOCK1_OFFSET _u(0x00001f3e)
#define OTP_DATA_PAGE15_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE15_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE15_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE15_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE15_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE15_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE15_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE15_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE15_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE15_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE15_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE15_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE15_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE15_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE15_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE15_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE15_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE15_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE15_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE15_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE15_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE15_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE15_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE15_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE15_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE15_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE15_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE15_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE15_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE15_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE15_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE15_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE15_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE15_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE15_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE15_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE15_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE15_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE15_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE15_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE15_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE15_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE15_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE15_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE16_LOCK0
// Description : Lock configuration LSBs for page 16 (addresses 0x800 through
//               0x87f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE16_LOCK0_OFFSET _u(0x00001f40)
#define OTP_DATA_PAGE16_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE16_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE16_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE16_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE16_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE16_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE16_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE16_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE16_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE16_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE16_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE16_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE16_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE16_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE16_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE16_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE16_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE16_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE16_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE16_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE16_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE16_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE16_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE16_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE16_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE16_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE16_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE16_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE16_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE16_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE16_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE16_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE16_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE16_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE16_LOCK1
// Description : Lock configuration MSBs for page 16 (addresses 0x800 through
//               0x87f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE16_LOCK1_OFFSET _u(0x00001f42)
#define OTP_DATA_PAGE16_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE16_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE16_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE16_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE16_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE16_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE16_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE16_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE16_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE16_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE16_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE16_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE16_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE16_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE16_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE16_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE16_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE16_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE16_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE16_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE16_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE16_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE16_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE16_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE16_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE16_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE16_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE16_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE16_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE16_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE16_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE16_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE16_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE16_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE16_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE16_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE16_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE16_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE16_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE16_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE16_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE16_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE16_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE16_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE17_LOCK0
// Description : Lock configuration LSBs for page 17 (addresses 0x880 through
//               0x8ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE17_LOCK0_OFFSET _u(0x00001f44)
#define OTP_DATA_PAGE17_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE17_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE17_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE17_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE17_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE17_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE17_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE17_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE17_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE17_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE17_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE17_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE17_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE17_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE17_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE17_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE17_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE17_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE17_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE17_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE17_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE17_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE17_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE17_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE17_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE17_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE17_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE17_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE17_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE17_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE17_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE17_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE17_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE17_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE17_LOCK1
// Description : Lock configuration MSBs for page 17 (addresses 0x880 through
//               0x8ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE17_LOCK1_OFFSET _u(0x00001f46)
#define OTP_DATA_PAGE17_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE17_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE17_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE17_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE17_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE17_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE17_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE17_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE17_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE17_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE17_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE17_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE17_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE17_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE17_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE17_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE17_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE17_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE17_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE17_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE17_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE17_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE17_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE17_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE17_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE17_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE17_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE17_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE17_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE17_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE17_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE17_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE17_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE17_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE17_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE17_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE17_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE17_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE17_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE17_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE17_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE17_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE17_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE17_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE18_LOCK0
// Description : Lock configuration LSBs for page 18 (addresses 0x900 through
//               0x97f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE18_LOCK0_OFFSET _u(0x00001f48)
#define OTP_DATA_PAGE18_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE18_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE18_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE18_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE18_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE18_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE18_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE18_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE18_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE18_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE18_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE18_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE18_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE18_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE18_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE18_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE18_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE18_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE18_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE18_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE18_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE18_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE18_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE18_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE18_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE18_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE18_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE18_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE18_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE18_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE18_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE18_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE18_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE18_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE18_LOCK1
// Description : Lock configuration MSBs for page 18 (addresses 0x900 through
//               0x97f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE18_LOCK1_OFFSET _u(0x00001f4a)
#define OTP_DATA_PAGE18_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE18_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE18_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE18_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE18_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE18_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE18_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE18_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE18_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE18_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE18_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE18_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE18_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE18_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE18_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE18_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE18_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE18_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE18_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE18_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE18_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE18_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE18_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE18_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE18_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE18_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE18_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE18_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE18_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE18_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE18_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE18_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE18_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE18_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE18_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE18_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE18_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE18_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE18_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE18_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE18_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE18_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE18_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE18_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE19_LOCK0
// Description : Lock configuration LSBs for page 19 (addresses 0x980 through
//               0x9ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE19_LOCK0_OFFSET _u(0x00001f4c)
#define OTP_DATA_PAGE19_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE19_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE19_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE19_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE19_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE19_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE19_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE19_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE19_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE19_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE19_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE19_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE19_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE19_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE19_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE19_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE19_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE19_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE19_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE19_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE19_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE19_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE19_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE19_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE19_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE19_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE19_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE19_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE19_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE19_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE19_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE19_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE19_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE19_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE19_LOCK1
// Description : Lock configuration MSBs for page 19 (addresses 0x980 through
//               0x9ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE19_LOCK1_OFFSET _u(0x00001f4e)
#define OTP_DATA_PAGE19_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE19_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE19_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE19_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE19_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE19_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE19_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE19_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE19_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE19_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE19_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE19_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE19_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE19_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE19_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE19_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE19_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE19_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE19_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE19_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE19_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE19_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE19_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE19_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE19_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE19_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE19_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE19_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE19_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE19_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE19_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE19_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE19_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE19_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE19_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE19_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE19_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE19_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE19_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE19_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE19_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE19_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE19_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE19_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE20_LOCK0
// Description : Lock configuration LSBs for page 20 (addresses 0xa00 through
//               0xa7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE20_LOCK0_OFFSET _u(0x00001f50)
#define OTP_DATA_PAGE20_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE20_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE20_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE20_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE20_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE20_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE20_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE20_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE20_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE20_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE20_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE20_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE20_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE20_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE20_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE20_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE20_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE20_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE20_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE20_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE20_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE20_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE20_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE20_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE20_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE20_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE20_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE20_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE20_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE20_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE20_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE20_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE20_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE20_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE20_LOCK1
// Description : Lock configuration MSBs for page 20 (addresses 0xa00 through
//               0xa7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE20_LOCK1_OFFSET _u(0x00001f52)
#define OTP_DATA_PAGE20_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE20_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE20_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE20_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE20_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE20_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE20_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE20_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE20_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE20_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE20_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE20_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE20_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE20_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE20_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE20_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE20_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE20_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE20_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE20_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE20_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE20_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE20_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE20_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE20_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE20_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE20_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE20_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE20_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE20_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE20_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE20_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE20_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE20_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE20_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE20_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE20_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE20_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE20_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE20_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE20_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE20_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE20_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE20_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE21_LOCK0
// Description : Lock configuration LSBs for page 21 (addresses 0xa80 through
//               0xaff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE21_LOCK0_OFFSET _u(0x00001f54)
#define OTP_DATA_PAGE21_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE21_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE21_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE21_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE21_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE21_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE21_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE21_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE21_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE21_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE21_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE21_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE21_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE21_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE21_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE21_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE21_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE21_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE21_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE21_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE21_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE21_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE21_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE21_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE21_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE21_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE21_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE21_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE21_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE21_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE21_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE21_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE21_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE21_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE21_LOCK1
// Description : Lock configuration MSBs for page 21 (addresses 0xa80 through
//               0xaff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE21_LOCK1_OFFSET _u(0x00001f56)
#define OTP_DATA_PAGE21_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE21_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE21_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE21_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE21_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE21_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE21_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE21_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE21_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE21_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE21_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE21_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE21_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE21_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE21_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE21_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE21_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE21_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE21_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE21_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE21_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE21_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE21_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE21_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE21_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE21_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE21_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE21_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE21_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE21_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE21_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE21_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE21_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE21_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE21_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE21_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE21_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE21_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE21_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE21_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE21_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE21_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE21_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE21_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE22_LOCK0
// Description : Lock configuration LSBs for page 22 (addresses 0xb00 through
//               0xb7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE22_LOCK0_OFFSET _u(0x00001f58)
#define OTP_DATA_PAGE22_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE22_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE22_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE22_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE22_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE22_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE22_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE22_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE22_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE22_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE22_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE22_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE22_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE22_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE22_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE22_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE22_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE22_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE22_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE22_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE22_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE22_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE22_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE22_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE22_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE22_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE22_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE22_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE22_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE22_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE22_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE22_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE22_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE22_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE22_LOCK1
// Description : Lock configuration MSBs for page 22 (addresses 0xb00 through
//               0xb7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE22_LOCK1_OFFSET _u(0x00001f5a)
#define OTP_DATA_PAGE22_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE22_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE22_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE22_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE22_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE22_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE22_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE22_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE22_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE22_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE22_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE22_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE22_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE22_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE22_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE22_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE22_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE22_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE22_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE22_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE22_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE22_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE22_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE22_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE22_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE22_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE22_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE22_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE22_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE22_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE22_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE22_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE22_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE22_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE22_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE22_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE22_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE22_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE22_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE22_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE22_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE22_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE22_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE22_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE23_LOCK0
// Description : Lock configuration LSBs for page 23 (addresses 0xb80 through
//               0xbff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE23_LOCK0_OFFSET _u(0x00001f5c)
#define OTP_DATA_PAGE23_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE23_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE23_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE23_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE23_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE23_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE23_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE23_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE23_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE23_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE23_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE23_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE23_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE23_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE23_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE23_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE23_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE23_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE23_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE23_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE23_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE23_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE23_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE23_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE23_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE23_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE23_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE23_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE23_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE23_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE23_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE23_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE23_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE23_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE23_LOCK1
// Description : Lock configuration MSBs for page 23 (addresses 0xb80 through
//               0xbff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE23_LOCK1_OFFSET _u(0x00001f5e)
#define OTP_DATA_PAGE23_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE23_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE23_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE23_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE23_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE23_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE23_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE23_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE23_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE23_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE23_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE23_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE23_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE23_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE23_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE23_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE23_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE23_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE23_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE23_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE23_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE23_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE23_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE23_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE23_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE23_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE23_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE23_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE23_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE23_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE23_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE23_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE23_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE23_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE23_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE23_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE23_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE23_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE23_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE23_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE23_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE23_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE23_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE23_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE24_LOCK0
// Description : Lock configuration LSBs for page 24 (addresses 0xc00 through
//               0xc7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE24_LOCK0_OFFSET _u(0x00001f60)
#define OTP_DATA_PAGE24_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE24_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE24_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE24_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE24_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE24_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE24_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE24_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE24_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE24_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE24_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE24_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE24_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE24_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE24_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE24_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE24_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE24_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE24_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE24_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE24_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE24_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE24_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE24_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE24_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE24_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE24_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE24_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE24_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE24_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE24_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE24_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE24_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE24_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE24_LOCK1
// Description : Lock configuration MSBs for page 24 (addresses 0xc00 through
//               0xc7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE24_LOCK1_OFFSET _u(0x00001f62)
#define OTP_DATA_PAGE24_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE24_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE24_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE24_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE24_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE24_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE24_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE24_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE24_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE24_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE24_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE24_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE24_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE24_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE24_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE24_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE24_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE24_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE24_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE24_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE24_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE24_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE24_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE24_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE24_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE24_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE24_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE24_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE24_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE24_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE24_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE24_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE24_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE24_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE24_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE24_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE24_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE24_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE24_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE24_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE24_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE24_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE24_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE24_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE25_LOCK0
// Description : Lock configuration LSBs for page 25 (addresses 0xc80 through
//               0xcff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE25_LOCK0_OFFSET _u(0x00001f64)
#define OTP_DATA_PAGE25_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE25_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE25_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE25_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE25_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE25_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE25_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE25_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE25_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE25_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE25_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE25_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE25_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE25_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE25_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE25_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE25_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE25_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE25_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE25_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE25_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE25_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE25_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE25_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE25_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE25_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE25_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE25_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE25_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE25_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE25_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE25_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE25_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE25_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE25_LOCK1
// Description : Lock configuration MSBs for page 25 (addresses 0xc80 through
//               0xcff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE25_LOCK1_OFFSET _u(0x00001f66)
#define OTP_DATA_PAGE25_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE25_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE25_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE25_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE25_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE25_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE25_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE25_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE25_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE25_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE25_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE25_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE25_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE25_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE25_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE25_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE25_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE25_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE25_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE25_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE25_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE25_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE25_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE25_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE25_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE25_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE25_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE25_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE25_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE25_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE25_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE25_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE25_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE25_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE25_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE25_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE25_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE25_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE25_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE25_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE25_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE25_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE25_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE25_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE26_LOCK0
// Description : Lock configuration LSBs for page 26 (addresses 0xd00 through
//               0xd7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE26_LOCK0_OFFSET _u(0x00001f68)
#define OTP_DATA_PAGE26_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE26_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE26_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE26_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE26_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE26_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE26_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE26_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE26_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE26_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE26_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE26_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE26_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE26_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE26_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE26_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE26_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE26_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE26_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE26_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE26_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE26_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE26_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE26_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE26_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE26_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE26_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE26_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE26_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE26_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE26_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE26_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE26_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE26_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE26_LOCK1
// Description : Lock configuration MSBs for page 26 (addresses 0xd00 through
//               0xd7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE26_LOCK1_OFFSET _u(0x00001f6a)
#define OTP_DATA_PAGE26_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE26_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE26_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE26_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE26_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE26_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE26_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE26_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE26_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE26_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE26_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE26_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE26_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE26_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE26_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE26_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE26_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE26_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE26_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE26_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE26_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE26_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE26_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE26_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE26_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE26_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE26_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE26_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE26_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE26_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE26_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE26_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE26_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE26_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE26_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE26_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE26_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE26_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE26_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE26_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE26_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE26_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE26_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE26_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE27_LOCK0
// Description : Lock configuration LSBs for page 27 (addresses 0xd80 through
//               0xdff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE27_LOCK0_OFFSET _u(0x00001f6c)
#define OTP_DATA_PAGE27_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE27_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE27_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE27_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE27_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE27_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE27_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE27_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE27_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE27_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE27_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE27_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE27_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE27_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE27_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE27_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE27_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE27_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE27_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE27_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE27_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE27_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE27_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE27_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE27_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE27_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE27_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE27_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE27_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE27_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE27_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE27_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE27_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE27_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE27_LOCK1
// Description : Lock configuration MSBs for page 27 (addresses 0xd80 through
//               0xdff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE27_LOCK1_OFFSET _u(0x00001f6e)
#define OTP_DATA_PAGE27_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE27_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE27_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE27_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE27_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE27_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE27_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE27_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE27_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE27_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE27_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE27_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE27_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE27_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE27_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE27_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE27_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE27_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE27_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE27_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE27_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE27_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE27_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE27_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE27_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE27_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE27_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE27_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE27_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE27_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE27_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE27_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE27_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE27_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE27_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE27_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE27_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE27_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE27_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE27_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE27_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE27_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE27_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE27_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE28_LOCK0
// Description : Lock configuration LSBs for page 28 (addresses 0xe00 through
//               0xe7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE28_LOCK0_OFFSET _u(0x00001f70)
#define OTP_DATA_PAGE28_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE28_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE28_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE28_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE28_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE28_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE28_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE28_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE28_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE28_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE28_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE28_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE28_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE28_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE28_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE28_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE28_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE28_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE28_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE28_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE28_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE28_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE28_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE28_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE28_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE28_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE28_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE28_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE28_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE28_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE28_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE28_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE28_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE28_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE28_LOCK1
// Description : Lock configuration MSBs for page 28 (addresses 0xe00 through
//               0xe7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE28_LOCK1_OFFSET _u(0x00001f72)
#define OTP_DATA_PAGE28_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE28_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE28_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE28_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE28_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE28_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE28_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE28_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE28_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE28_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE28_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE28_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE28_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE28_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE28_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE28_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE28_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE28_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE28_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE28_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE28_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE28_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE28_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE28_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE28_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE28_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE28_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE28_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE28_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE28_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE28_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE28_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE28_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE28_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE28_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE28_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE28_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE28_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE28_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE28_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE28_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE28_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE28_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE28_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE29_LOCK0
// Description : Lock configuration LSBs for page 29 (addresses 0xe80 through
//               0xeff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE29_LOCK0_OFFSET _u(0x00001f74)
#define OTP_DATA_PAGE29_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE29_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE29_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE29_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE29_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE29_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE29_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE29_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE29_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE29_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE29_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE29_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE29_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE29_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE29_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE29_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE29_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE29_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE29_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE29_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE29_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE29_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE29_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE29_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE29_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE29_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE29_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE29_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE29_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE29_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE29_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE29_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE29_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE29_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE29_LOCK1
// Description : Lock configuration MSBs for page 29 (addresses 0xe80 through
//               0xeff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE29_LOCK1_OFFSET _u(0x00001f76)
#define OTP_DATA_PAGE29_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE29_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE29_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE29_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE29_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE29_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE29_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE29_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE29_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE29_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE29_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE29_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE29_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE29_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE29_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE29_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE29_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE29_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE29_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE29_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE29_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE29_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE29_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE29_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE29_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE29_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE29_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE29_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE29_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE29_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE29_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE29_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE29_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE29_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE29_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE29_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE29_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE29_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE29_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE29_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE29_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE29_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE29_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE29_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE30_LOCK0
// Description : Lock configuration LSBs for page 30 (addresses 0xf00 through
//               0xf7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE30_LOCK0_OFFSET _u(0x00001f78)
#define OTP_DATA_PAGE30_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE30_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE30_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE30_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE30_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE30_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE30_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE30_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE30_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE30_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE30_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE30_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE30_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE30_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE30_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE30_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE30_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE30_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE30_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE30_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE30_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE30_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE30_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE30_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE30_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE30_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE30_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE30_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE30_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE30_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE30_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE30_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE30_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE30_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE30_LOCK1
// Description : Lock configuration MSBs for page 30 (addresses 0xf00 through
//               0xf7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE30_LOCK1_OFFSET _u(0x00001f7a)
#define OTP_DATA_PAGE30_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE30_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE30_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE30_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE30_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE30_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE30_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE30_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE30_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE30_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE30_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE30_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE30_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE30_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE30_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE30_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE30_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE30_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE30_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE30_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE30_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE30_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE30_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE30_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE30_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE30_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE30_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE30_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE30_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE30_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE30_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE30_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE30_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE30_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE30_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE30_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE30_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE30_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE30_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE30_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE30_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE30_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE30_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE30_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE31_LOCK0
// Description : Lock configuration LSBs for page 31 (addresses 0xf80 through
//               0xfff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE31_LOCK0_OFFSET _u(0x00001f7c)
#define OTP_DATA_PAGE31_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE31_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE31_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE31_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE31_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE31_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE31_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE31_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE31_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE31_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE31_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE31_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE31_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE31_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE31_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE31_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE31_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE31_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE31_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE31_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE31_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE31_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE31_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE31_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE31_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE31_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE31_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE31_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE31_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE31_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE31_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE31_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE31_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE31_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE31_LOCK1
// Description : Lock configuration MSBs for page 31 (addresses 0xf80 through
//               0xfff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE31_LOCK1_OFFSET _u(0x00001f7e)
#define OTP_DATA_PAGE31_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE31_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE31_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE31_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE31_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE31_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE31_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE31_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE31_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE31_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE31_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE31_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE31_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE31_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE31_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE31_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE31_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE31_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE31_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE31_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE31_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE31_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE31_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE31_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE31_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE31_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE31_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE31_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE31_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE31_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE31_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE31_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE31_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE31_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE31_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE31_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE31_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE31_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE31_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE31_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE31_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE31_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE31_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE31_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE32_LOCK0
// Description : Lock configuration LSBs for page 32 (addresses 0x1000 through
//               0x107f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE32_LOCK0_OFFSET _u(0x00001f80)
#define OTP_DATA_PAGE32_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE32_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE32_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE32_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE32_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE32_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE32_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE32_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE32_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE32_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE32_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE32_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE32_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE32_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE32_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE32_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE32_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE32_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE32_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE32_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE32_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE32_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE32_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE32_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE32_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE32_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE32_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE32_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE32_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE32_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE32_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE32_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE32_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE32_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE32_LOCK1
// Description : Lock configuration MSBs for page 32 (addresses 0x1000 through
//               0x107f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE32_LOCK1_OFFSET _u(0x00001f82)
#define OTP_DATA_PAGE32_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE32_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE32_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE32_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE32_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE32_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE32_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE32_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE32_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE32_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE32_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE32_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE32_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE32_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE32_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE32_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE32_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE32_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE32_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE32_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE32_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE32_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE32_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE32_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE32_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE32_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE32_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE32_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE32_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE32_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE32_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE32_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE32_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE32_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE32_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE32_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE32_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE32_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE32_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE32_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE32_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE32_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE32_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE32_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE33_LOCK0
// Description : Lock configuration LSBs for page 33 (addresses 0x1080 through
//               0x10ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE33_LOCK0_OFFSET _u(0x00001f84)
#define OTP_DATA_PAGE33_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE33_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE33_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE33_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE33_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE33_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE33_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE33_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE33_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE33_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE33_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE33_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE33_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE33_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE33_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE33_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE33_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE33_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE33_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE33_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE33_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE33_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE33_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE33_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE33_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE33_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE33_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE33_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE33_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE33_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE33_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE33_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE33_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE33_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE33_LOCK1
// Description : Lock configuration MSBs for page 33 (addresses 0x1080 through
//               0x10ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE33_LOCK1_OFFSET _u(0x00001f86)
#define OTP_DATA_PAGE33_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE33_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE33_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE33_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE33_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE33_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE33_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE33_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE33_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE33_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE33_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE33_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE33_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE33_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE33_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE33_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE33_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE33_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE33_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE33_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE33_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE33_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE33_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE33_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE33_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE33_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE33_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE33_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE33_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE33_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE33_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE33_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE33_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE33_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE33_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE33_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE33_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE33_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE33_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE33_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE33_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE33_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE33_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE33_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE34_LOCK0
// Description : Lock configuration LSBs for page 34 (addresses 0x1100 through
//               0x117f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE34_LOCK0_OFFSET _u(0x00001f88)
#define OTP_DATA_PAGE34_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE34_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE34_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE34_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE34_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE34_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE34_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE34_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE34_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE34_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE34_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE34_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE34_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE34_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE34_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE34_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE34_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE34_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE34_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE34_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE34_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE34_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE34_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE34_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE34_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE34_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE34_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE34_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE34_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE34_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE34_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE34_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE34_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE34_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE34_LOCK1
// Description : Lock configuration MSBs for page 34 (addresses 0x1100 through
//               0x117f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE34_LOCK1_OFFSET _u(0x00001f8a)
#define OTP_DATA_PAGE34_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE34_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE34_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE34_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE34_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE34_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE34_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE34_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE34_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE34_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE34_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE34_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE34_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE34_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE34_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE34_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE34_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE34_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE34_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE34_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE34_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE34_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE34_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE34_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE34_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE34_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE34_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE34_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE34_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE34_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE34_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE34_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE34_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE34_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE34_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE34_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE34_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE34_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE34_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE34_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE34_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE34_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE34_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE34_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE35_LOCK0
// Description : Lock configuration LSBs for page 35 (addresses 0x1180 through
//               0x11ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE35_LOCK0_OFFSET _u(0x00001f8c)
#define OTP_DATA_PAGE35_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE35_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE35_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE35_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE35_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE35_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE35_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE35_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE35_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE35_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE35_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE35_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE35_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE35_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE35_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE35_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE35_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE35_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE35_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE35_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE35_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE35_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE35_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE35_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE35_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE35_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE35_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE35_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE35_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE35_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE35_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE35_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE35_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE35_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE35_LOCK1
// Description : Lock configuration MSBs for page 35 (addresses 0x1180 through
//               0x11ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE35_LOCK1_OFFSET _u(0x00001f8e)
#define OTP_DATA_PAGE35_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE35_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE35_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE35_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE35_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE35_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE35_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE35_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE35_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE35_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE35_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE35_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE35_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE35_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE35_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE35_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE35_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE35_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE35_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE35_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE35_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE35_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE35_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE35_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE35_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE35_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE35_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE35_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE35_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE35_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE35_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE35_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE35_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE35_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE35_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE35_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE35_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE35_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE35_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE35_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE35_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE35_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE35_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE35_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE36_LOCK0
// Description : Lock configuration LSBs for page 36 (addresses 0x1200 through
//               0x127f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE36_LOCK0_OFFSET _u(0x00001f90)
#define OTP_DATA_PAGE36_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE36_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE36_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE36_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE36_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE36_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE36_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE36_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE36_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE36_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE36_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE36_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE36_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE36_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE36_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE36_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE36_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE36_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE36_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE36_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE36_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE36_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE36_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE36_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE36_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE36_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE36_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE36_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE36_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE36_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE36_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE36_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE36_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE36_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE36_LOCK1
// Description : Lock configuration MSBs for page 36 (addresses 0x1200 through
//               0x127f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE36_LOCK1_OFFSET _u(0x00001f92)
#define OTP_DATA_PAGE36_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE36_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE36_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE36_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE36_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE36_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE36_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE36_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE36_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE36_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE36_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE36_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE36_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE36_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE36_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE36_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE36_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE36_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE36_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE36_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE36_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE36_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE36_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE36_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE36_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE36_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE36_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE36_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE36_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE36_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE36_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE36_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE36_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE36_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE36_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE36_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE36_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE36_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE36_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE36_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE36_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE36_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE36_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE36_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE37_LOCK0
// Description : Lock configuration LSBs for page 37 (addresses 0x1280 through
//               0x12ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE37_LOCK0_OFFSET _u(0x00001f94)
#define OTP_DATA_PAGE37_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE37_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE37_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE37_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE37_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE37_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE37_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE37_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE37_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE37_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE37_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE37_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE37_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE37_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE37_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE37_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE37_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE37_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE37_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE37_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE37_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE37_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE37_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE37_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE37_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE37_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE37_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE37_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE37_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE37_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE37_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE37_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE37_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE37_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE37_LOCK1
// Description : Lock configuration MSBs for page 37 (addresses 0x1280 through
//               0x12ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE37_LOCK1_OFFSET _u(0x00001f96)
#define OTP_DATA_PAGE37_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE37_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE37_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE37_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE37_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE37_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE37_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE37_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE37_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE37_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE37_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE37_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE37_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE37_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE37_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE37_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE37_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE37_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE37_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE37_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE37_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE37_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE37_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE37_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE37_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE37_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE37_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE37_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE37_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE37_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE37_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE37_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE37_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE37_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE37_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE37_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE37_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE37_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE37_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE37_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE37_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE37_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE37_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE37_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE38_LOCK0
// Description : Lock configuration LSBs for page 38 (addresses 0x1300 through
//               0x137f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE38_LOCK0_OFFSET _u(0x00001f98)
#define OTP_DATA_PAGE38_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE38_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE38_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE38_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE38_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE38_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE38_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE38_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE38_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE38_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE38_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE38_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE38_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE38_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE38_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE38_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE38_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE38_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE38_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE38_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE38_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE38_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE38_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE38_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE38_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE38_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE38_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE38_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE38_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE38_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE38_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE38_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE38_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE38_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE38_LOCK1
// Description : Lock configuration MSBs for page 38 (addresses 0x1300 through
//               0x137f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE38_LOCK1_OFFSET _u(0x00001f9a)
#define OTP_DATA_PAGE38_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE38_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE38_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE38_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE38_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE38_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE38_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE38_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE38_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE38_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE38_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE38_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE38_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE38_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE38_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE38_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE38_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE38_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE38_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE38_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE38_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE38_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE38_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE38_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE38_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE38_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE38_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE38_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE38_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE38_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE38_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE38_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE38_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE38_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE38_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE38_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE38_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE38_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE38_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE38_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE38_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE38_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE38_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE38_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE39_LOCK0
// Description : Lock configuration LSBs for page 39 (addresses 0x1380 through
//               0x13ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE39_LOCK0_OFFSET _u(0x00001f9c)
#define OTP_DATA_PAGE39_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE39_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE39_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE39_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE39_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE39_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE39_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE39_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE39_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE39_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE39_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE39_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE39_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE39_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE39_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE39_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE39_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE39_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE39_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE39_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE39_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE39_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE39_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE39_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE39_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE39_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE39_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE39_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE39_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE39_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE39_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE39_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE39_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE39_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE39_LOCK1
// Description : Lock configuration MSBs for page 39 (addresses 0x1380 through
//               0x13ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE39_LOCK1_OFFSET _u(0x00001f9e)
#define OTP_DATA_PAGE39_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE39_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE39_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE39_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE39_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE39_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE39_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE39_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE39_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE39_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE39_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE39_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE39_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE39_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE39_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE39_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE39_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE39_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE39_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE39_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE39_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE39_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE39_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE39_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE39_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE39_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE39_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE39_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE39_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE39_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE39_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE39_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE39_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE39_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE39_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE39_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE39_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE39_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE39_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE39_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE39_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE39_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE39_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE39_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE40_LOCK0
// Description : Lock configuration LSBs for page 40 (addresses 0x1400 through
//               0x147f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE40_LOCK0_OFFSET _u(0x00001fa0)
#define OTP_DATA_PAGE40_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE40_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE40_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE40_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE40_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE40_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE40_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE40_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE40_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE40_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE40_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE40_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE40_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE40_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE40_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE40_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE40_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE40_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE40_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE40_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE40_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE40_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE40_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE40_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE40_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE40_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE40_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE40_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE40_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE40_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE40_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE40_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE40_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE40_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE40_LOCK1
// Description : Lock configuration MSBs for page 40 (addresses 0x1400 through
//               0x147f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE40_LOCK1_OFFSET _u(0x00001fa2)
#define OTP_DATA_PAGE40_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE40_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE40_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE40_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE40_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE40_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE40_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE40_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE40_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE40_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE40_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE40_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE40_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE40_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE40_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE40_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE40_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE40_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE40_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE40_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE40_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE40_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE40_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE40_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE40_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE40_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE40_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE40_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE40_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE40_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE40_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE40_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE40_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE40_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE40_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE40_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE40_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE40_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE40_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE40_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE40_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE40_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE40_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE40_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE41_LOCK0
// Description : Lock configuration LSBs for page 41 (addresses 0x1480 through
//               0x14ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE41_LOCK0_OFFSET _u(0x00001fa4)
#define OTP_DATA_PAGE41_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE41_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE41_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE41_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE41_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE41_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE41_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE41_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE41_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE41_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE41_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE41_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE41_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE41_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE41_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE41_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE41_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE41_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE41_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE41_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE41_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE41_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE41_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE41_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE41_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE41_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE41_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE41_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE41_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE41_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE41_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE41_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE41_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE41_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE41_LOCK1
// Description : Lock configuration MSBs for page 41 (addresses 0x1480 through
//               0x14ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE41_LOCK1_OFFSET _u(0x00001fa6)
#define OTP_DATA_PAGE41_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE41_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE41_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE41_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE41_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE41_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE41_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE41_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE41_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE41_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE41_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE41_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE41_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE41_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE41_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE41_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE41_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE41_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE41_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE41_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE41_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE41_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE41_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE41_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE41_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE41_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE41_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE41_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE41_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE41_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE41_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE41_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE41_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE41_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE41_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE41_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE41_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE41_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE41_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE41_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE41_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE41_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE41_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE41_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE42_LOCK0
// Description : Lock configuration LSBs for page 42 (addresses 0x1500 through
//               0x157f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE42_LOCK0_OFFSET _u(0x00001fa8)
#define OTP_DATA_PAGE42_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE42_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE42_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE42_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE42_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE42_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE42_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE42_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE42_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE42_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE42_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE42_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE42_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE42_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE42_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE42_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE42_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE42_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE42_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE42_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE42_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE42_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE42_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE42_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE42_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE42_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE42_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE42_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE42_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE42_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE42_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE42_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE42_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE42_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE42_LOCK1
// Description : Lock configuration MSBs for page 42 (addresses 0x1500 through
//               0x157f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE42_LOCK1_OFFSET _u(0x00001faa)
#define OTP_DATA_PAGE42_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE42_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE42_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE42_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE42_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE42_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE42_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE42_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE42_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE42_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE42_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE42_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE42_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE42_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE42_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE42_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE42_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE42_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE42_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE42_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE42_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE42_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE42_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE42_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE42_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE42_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE42_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE42_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE42_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE42_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE42_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE42_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE42_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE42_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE42_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE42_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE42_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE42_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE42_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE42_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE42_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE42_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE42_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE42_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE43_LOCK0
// Description : Lock configuration LSBs for page 43 (addresses 0x1580 through
//               0x15ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE43_LOCK0_OFFSET _u(0x00001fac)
#define OTP_DATA_PAGE43_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE43_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE43_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE43_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE43_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE43_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE43_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE43_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE43_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE43_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE43_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE43_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE43_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE43_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE43_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE43_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE43_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE43_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE43_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE43_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE43_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE43_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE43_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE43_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE43_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE43_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE43_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE43_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE43_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE43_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE43_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE43_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE43_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE43_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE43_LOCK1
// Description : Lock configuration MSBs for page 43 (addresses 0x1580 through
//               0x15ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE43_LOCK1_OFFSET _u(0x00001fae)
#define OTP_DATA_PAGE43_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE43_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE43_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE43_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE43_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE43_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE43_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE43_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE43_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE43_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE43_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE43_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE43_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE43_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE43_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE43_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE43_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE43_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE43_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE43_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE43_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE43_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE43_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE43_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE43_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE43_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE43_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE43_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE43_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE43_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE43_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE43_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE43_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE43_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE43_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE43_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE43_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE43_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE43_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE43_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE43_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE43_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE43_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE43_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE44_LOCK0
// Description : Lock configuration LSBs for page 44 (addresses 0x1600 through
//               0x167f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE44_LOCK0_OFFSET _u(0x00001fb0)
#define OTP_DATA_PAGE44_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE44_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE44_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE44_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE44_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE44_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE44_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE44_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE44_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE44_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE44_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE44_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE44_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE44_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE44_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE44_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE44_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE44_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE44_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE44_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE44_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE44_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE44_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE44_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE44_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE44_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE44_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE44_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE44_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE44_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE44_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE44_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE44_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE44_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE44_LOCK1
// Description : Lock configuration MSBs for page 44 (addresses 0x1600 through
//               0x167f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE44_LOCK1_OFFSET _u(0x00001fb2)
#define OTP_DATA_PAGE44_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE44_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE44_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE44_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE44_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE44_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE44_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE44_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE44_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE44_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE44_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE44_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE44_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE44_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE44_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE44_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE44_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE44_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE44_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE44_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE44_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE44_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE44_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE44_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE44_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE44_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE44_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE44_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE44_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE44_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE44_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE44_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE44_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE44_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE44_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE44_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE44_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE44_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE44_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE44_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE44_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE44_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE44_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE44_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE45_LOCK0
// Description : Lock configuration LSBs for page 45 (addresses 0x1680 through
//               0x16ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE45_LOCK0_OFFSET _u(0x00001fb4)
#define OTP_DATA_PAGE45_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE45_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE45_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE45_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE45_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE45_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE45_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE45_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE45_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE45_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE45_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE45_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE45_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE45_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE45_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE45_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE45_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE45_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE45_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE45_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE45_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE45_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE45_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE45_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE45_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE45_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE45_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE45_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE45_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE45_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE45_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE45_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE45_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE45_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE45_LOCK1
// Description : Lock configuration MSBs for page 45 (addresses 0x1680 through
//               0x16ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE45_LOCK1_OFFSET _u(0x00001fb6)
#define OTP_DATA_PAGE45_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE45_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE45_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE45_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE45_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE45_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE45_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE45_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE45_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE45_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE45_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE45_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE45_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE45_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE45_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE45_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE45_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE45_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE45_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE45_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE45_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE45_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE45_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE45_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE45_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE45_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE45_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE45_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE45_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE45_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE45_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE45_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE45_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE45_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE45_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE45_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE45_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE45_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE45_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE45_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE45_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE45_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE45_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE45_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE46_LOCK0
// Description : Lock configuration LSBs for page 46 (addresses 0x1700 through
//               0x177f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE46_LOCK0_OFFSET _u(0x00001fb8)
#define OTP_DATA_PAGE46_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE46_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE46_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE46_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE46_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE46_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE46_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE46_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE46_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE46_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE46_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE46_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE46_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE46_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE46_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE46_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE46_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE46_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE46_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE46_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE46_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE46_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE46_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE46_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE46_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE46_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE46_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE46_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE46_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE46_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE46_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE46_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE46_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE46_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE46_LOCK1
// Description : Lock configuration MSBs for page 46 (addresses 0x1700 through
//               0x177f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE46_LOCK1_OFFSET _u(0x00001fba)
#define OTP_DATA_PAGE46_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE46_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE46_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE46_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE46_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE46_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE46_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE46_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE46_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE46_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE46_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE46_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE46_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE46_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE46_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE46_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE46_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE46_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE46_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE46_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE46_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE46_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE46_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE46_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE46_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE46_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE46_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE46_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE46_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE46_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE46_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE46_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE46_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE46_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE46_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE46_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE46_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE46_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE46_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE46_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE46_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE46_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE46_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE46_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE47_LOCK0
// Description : Lock configuration LSBs for page 47 (addresses 0x1780 through
//               0x17ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE47_LOCK0_OFFSET _u(0x00001fbc)
#define OTP_DATA_PAGE47_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE47_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE47_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE47_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE47_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE47_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE47_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE47_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE47_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE47_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE47_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE47_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE47_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE47_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE47_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE47_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE47_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE47_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE47_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE47_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE47_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE47_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE47_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE47_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE47_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE47_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE47_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE47_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE47_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE47_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE47_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE47_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE47_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE47_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE47_LOCK1
// Description : Lock configuration MSBs for page 47 (addresses 0x1780 through
//               0x17ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE47_LOCK1_OFFSET _u(0x00001fbe)
#define OTP_DATA_PAGE47_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE47_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE47_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE47_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE47_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE47_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE47_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE47_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE47_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE47_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE47_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE47_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE47_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE47_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE47_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE47_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE47_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE47_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE47_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE47_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE47_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE47_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE47_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE47_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE47_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE47_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE47_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE47_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE47_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE47_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE47_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE47_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE47_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE47_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE47_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE47_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE47_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE47_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE47_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE47_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE47_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE47_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE47_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE47_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE48_LOCK0
// Description : Lock configuration LSBs for page 48 (addresses 0x1800 through
//               0x187f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE48_LOCK0_OFFSET _u(0x00001fc0)
#define OTP_DATA_PAGE48_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE48_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE48_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE48_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE48_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE48_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE48_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE48_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE48_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE48_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE48_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE48_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE48_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE48_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE48_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE48_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE48_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE48_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE48_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE48_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE48_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE48_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE48_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE48_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE48_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE48_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE48_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE48_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE48_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE48_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE48_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE48_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE48_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE48_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE48_LOCK1
// Description : Lock configuration MSBs for page 48 (addresses 0x1800 through
//               0x187f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE48_LOCK1_OFFSET _u(0x00001fc2)
#define OTP_DATA_PAGE48_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE48_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE48_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE48_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE48_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE48_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE48_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE48_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE48_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE48_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE48_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE48_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE48_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE48_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE48_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE48_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE48_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE48_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE48_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE48_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE48_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE48_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE48_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE48_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE48_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE48_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE48_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE48_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE48_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE48_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE48_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE48_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE48_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE48_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE48_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE48_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE48_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE48_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE48_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE48_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE48_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE48_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE48_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE48_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE49_LOCK0
// Description : Lock configuration LSBs for page 49 (addresses 0x1880 through
//               0x18ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE49_LOCK0_OFFSET _u(0x00001fc4)
#define OTP_DATA_PAGE49_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE49_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE49_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE49_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE49_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE49_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE49_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE49_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE49_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE49_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE49_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE49_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE49_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE49_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE49_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE49_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE49_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE49_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE49_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE49_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE49_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE49_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE49_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE49_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE49_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE49_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE49_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE49_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE49_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE49_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE49_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE49_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE49_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE49_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE49_LOCK1
// Description : Lock configuration MSBs for page 49 (addresses 0x1880 through
//               0x18ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE49_LOCK1_OFFSET _u(0x00001fc6)
#define OTP_DATA_PAGE49_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE49_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE49_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE49_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE49_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE49_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE49_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE49_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE49_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE49_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE49_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE49_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE49_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE49_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE49_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE49_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE49_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE49_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE49_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE49_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE49_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE49_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE49_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE49_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE49_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE49_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE49_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE49_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE49_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE49_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE49_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE49_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE49_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE49_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE49_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE49_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE49_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE49_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE49_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE49_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE49_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE49_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE49_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE49_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE50_LOCK0
// Description : Lock configuration LSBs for page 50 (addresses 0x1900 through
//               0x197f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE50_LOCK0_OFFSET _u(0x00001fc8)
#define OTP_DATA_PAGE50_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE50_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE50_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE50_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE50_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE50_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE50_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE50_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE50_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE50_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE50_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE50_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE50_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE50_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE50_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE50_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE50_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE50_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE50_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE50_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE50_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE50_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE50_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE50_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE50_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE50_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE50_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE50_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE50_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE50_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE50_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE50_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE50_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE50_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE50_LOCK1
// Description : Lock configuration MSBs for page 50 (addresses 0x1900 through
//               0x197f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE50_LOCK1_OFFSET _u(0x00001fca)
#define OTP_DATA_PAGE50_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE50_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE50_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE50_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE50_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE50_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE50_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE50_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE50_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE50_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE50_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE50_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE50_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE50_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE50_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE50_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE50_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE50_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE50_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE50_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE50_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE50_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE50_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE50_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE50_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE50_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE50_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE50_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE50_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE50_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE50_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE50_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE50_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE50_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE50_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE50_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE50_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE50_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE50_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE50_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE50_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE50_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE50_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE50_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE51_LOCK0
// Description : Lock configuration LSBs for page 51 (addresses 0x1980 through
//               0x19ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE51_LOCK0_OFFSET _u(0x00001fcc)
#define OTP_DATA_PAGE51_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE51_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE51_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE51_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE51_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE51_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE51_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE51_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE51_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE51_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE51_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE51_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE51_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE51_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE51_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE51_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE51_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE51_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE51_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE51_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE51_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE51_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE51_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE51_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE51_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE51_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE51_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE51_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE51_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE51_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE51_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE51_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE51_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE51_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE51_LOCK1
// Description : Lock configuration MSBs for page 51 (addresses 0x1980 through
//               0x19ff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE51_LOCK1_OFFSET _u(0x00001fce)
#define OTP_DATA_PAGE51_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE51_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE51_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE51_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE51_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE51_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE51_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE51_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE51_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE51_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE51_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE51_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE51_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE51_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE51_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE51_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE51_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE51_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE51_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE51_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE51_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE51_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE51_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE51_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE51_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE51_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE51_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE51_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE51_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE51_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE51_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE51_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE51_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE51_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE51_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE51_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE51_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE51_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE51_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE51_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE51_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE51_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE51_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE51_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE52_LOCK0
// Description : Lock configuration LSBs for page 52 (addresses 0x1a00 through
//               0x1a7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE52_LOCK0_OFFSET _u(0x00001fd0)
#define OTP_DATA_PAGE52_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE52_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE52_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE52_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE52_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE52_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE52_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE52_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE52_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE52_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE52_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE52_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE52_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE52_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE52_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE52_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE52_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE52_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE52_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE52_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE52_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE52_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE52_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE52_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE52_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE52_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE52_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE52_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE52_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE52_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE52_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE52_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE52_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE52_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE52_LOCK1
// Description : Lock configuration MSBs for page 52 (addresses 0x1a00 through
//               0x1a7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE52_LOCK1_OFFSET _u(0x00001fd2)
#define OTP_DATA_PAGE52_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE52_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE52_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE52_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE52_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE52_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE52_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE52_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE52_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE52_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE52_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE52_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE52_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE52_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE52_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE52_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE52_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE52_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE52_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE52_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE52_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE52_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE52_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE52_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE52_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE52_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE52_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE52_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE52_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE52_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE52_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE52_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE52_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE52_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE52_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE52_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE52_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE52_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE52_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE52_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE52_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE52_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE52_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE52_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE53_LOCK0
// Description : Lock configuration LSBs for page 53 (addresses 0x1a80 through
//               0x1aff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE53_LOCK0_OFFSET _u(0x00001fd4)
#define OTP_DATA_PAGE53_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE53_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE53_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE53_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE53_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE53_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE53_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE53_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE53_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE53_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE53_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE53_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE53_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE53_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE53_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE53_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE53_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE53_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE53_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE53_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE53_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE53_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE53_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE53_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE53_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE53_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE53_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE53_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE53_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE53_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE53_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE53_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE53_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE53_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE53_LOCK1
// Description : Lock configuration MSBs for page 53 (addresses 0x1a80 through
//               0x1aff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE53_LOCK1_OFFSET _u(0x00001fd6)
#define OTP_DATA_PAGE53_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE53_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE53_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE53_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE53_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE53_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE53_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE53_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE53_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE53_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE53_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE53_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE53_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE53_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE53_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE53_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE53_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE53_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE53_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE53_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE53_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE53_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE53_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE53_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE53_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE53_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE53_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE53_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE53_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE53_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE53_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE53_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE53_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE53_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE53_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE53_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE53_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE53_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE53_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE53_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE53_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE53_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE53_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE53_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE54_LOCK0
// Description : Lock configuration LSBs for page 54 (addresses 0x1b00 through
//               0x1b7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE54_LOCK0_OFFSET _u(0x00001fd8)
#define OTP_DATA_PAGE54_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE54_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE54_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE54_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE54_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE54_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE54_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE54_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE54_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE54_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE54_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE54_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE54_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE54_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE54_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE54_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE54_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE54_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE54_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE54_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE54_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE54_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE54_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE54_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE54_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE54_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE54_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE54_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE54_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE54_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE54_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE54_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE54_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE54_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE54_LOCK1
// Description : Lock configuration MSBs for page 54 (addresses 0x1b00 through
//               0x1b7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE54_LOCK1_OFFSET _u(0x00001fda)
#define OTP_DATA_PAGE54_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE54_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE54_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE54_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE54_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE54_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE54_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE54_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE54_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE54_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE54_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE54_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE54_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE54_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE54_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE54_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE54_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE54_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE54_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE54_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE54_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE54_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE54_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE54_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE54_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE54_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE54_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE54_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE54_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE54_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE54_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE54_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE54_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE54_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE54_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE54_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE54_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE54_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE54_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE54_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE54_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE54_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE54_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE54_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE55_LOCK0
// Description : Lock configuration LSBs for page 55 (addresses 0x1b80 through
//               0x1bff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE55_LOCK0_OFFSET _u(0x00001fdc)
#define OTP_DATA_PAGE55_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE55_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE55_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE55_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE55_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE55_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE55_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE55_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE55_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE55_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE55_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE55_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE55_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE55_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE55_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE55_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE55_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE55_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE55_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE55_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE55_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE55_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE55_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE55_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE55_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE55_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE55_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE55_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE55_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE55_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE55_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE55_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE55_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE55_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE55_LOCK1
// Description : Lock configuration MSBs for page 55 (addresses 0x1b80 through
//               0x1bff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE55_LOCK1_OFFSET _u(0x00001fde)
#define OTP_DATA_PAGE55_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE55_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE55_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE55_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE55_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE55_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE55_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE55_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE55_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE55_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE55_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE55_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE55_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE55_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE55_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE55_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE55_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE55_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE55_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE55_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE55_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE55_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE55_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE55_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE55_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE55_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE55_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE55_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE55_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE55_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE55_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE55_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE55_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE55_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE55_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE55_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE55_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE55_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE55_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE55_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE55_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE55_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE55_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE55_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE56_LOCK0
// Description : Lock configuration LSBs for page 56 (addresses 0x1c00 through
//               0x1c7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE56_LOCK0_OFFSET _u(0x00001fe0)
#define OTP_DATA_PAGE56_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE56_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE56_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE56_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE56_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE56_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE56_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE56_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE56_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE56_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE56_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE56_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE56_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE56_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE56_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE56_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE56_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE56_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE56_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE56_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE56_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE56_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE56_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE56_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE56_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE56_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE56_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE56_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE56_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE56_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE56_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE56_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE56_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE56_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE56_LOCK1
// Description : Lock configuration MSBs for page 56 (addresses 0x1c00 through
//               0x1c7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE56_LOCK1_OFFSET _u(0x00001fe2)
#define OTP_DATA_PAGE56_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE56_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE56_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE56_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE56_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE56_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE56_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE56_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE56_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE56_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE56_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE56_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE56_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE56_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE56_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE56_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE56_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE56_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE56_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE56_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE56_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE56_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE56_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE56_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE56_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE56_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE56_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE56_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE56_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE56_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE56_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE56_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE56_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE56_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE56_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE56_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE56_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE56_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE56_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE56_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE56_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE56_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE56_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE56_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE57_LOCK0
// Description : Lock configuration LSBs for page 57 (addresses 0x1c80 through
//               0x1cff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE57_LOCK0_OFFSET _u(0x00001fe4)
#define OTP_DATA_PAGE57_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE57_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE57_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE57_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE57_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE57_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE57_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE57_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE57_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE57_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE57_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE57_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE57_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE57_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE57_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE57_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE57_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE57_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE57_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE57_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE57_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE57_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE57_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE57_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE57_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE57_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE57_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE57_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE57_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE57_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE57_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE57_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE57_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE57_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE57_LOCK1
// Description : Lock configuration MSBs for page 57 (addresses 0x1c80 through
//               0x1cff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE57_LOCK1_OFFSET _u(0x00001fe6)
#define OTP_DATA_PAGE57_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE57_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE57_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE57_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE57_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE57_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE57_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE57_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE57_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE57_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE57_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE57_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE57_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE57_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE57_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE57_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE57_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE57_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE57_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE57_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE57_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE57_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE57_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE57_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE57_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE57_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE57_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE57_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE57_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE57_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE57_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE57_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE57_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE57_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE57_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE57_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE57_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE57_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE57_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE57_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE57_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE57_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE57_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE57_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE58_LOCK0
// Description : Lock configuration LSBs for page 58 (addresses 0x1d00 through
//               0x1d7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE58_LOCK0_OFFSET _u(0x00001fe8)
#define OTP_DATA_PAGE58_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE58_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE58_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE58_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE58_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE58_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE58_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE58_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE58_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE58_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE58_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE58_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE58_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE58_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE58_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE58_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE58_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE58_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE58_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE58_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE58_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE58_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE58_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE58_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE58_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE58_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE58_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE58_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE58_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE58_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE58_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE58_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE58_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE58_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE58_LOCK1
// Description : Lock configuration MSBs for page 58 (addresses 0x1d00 through
//               0x1d7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE58_LOCK1_OFFSET _u(0x00001fea)
#define OTP_DATA_PAGE58_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE58_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE58_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE58_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE58_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE58_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE58_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE58_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE58_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE58_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE58_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE58_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE58_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE58_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE58_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE58_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE58_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE58_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE58_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE58_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE58_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE58_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE58_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE58_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE58_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE58_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE58_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE58_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE58_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE58_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE58_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE58_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE58_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE58_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE58_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE58_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE58_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE58_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE58_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE58_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE58_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE58_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE58_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE58_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE59_LOCK0
// Description : Lock configuration LSBs for page 59 (addresses 0x1d80 through
//               0x1dff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE59_LOCK0_OFFSET _u(0x00001fec)
#define OTP_DATA_PAGE59_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE59_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE59_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE59_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE59_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE59_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE59_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE59_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE59_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE59_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE59_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE59_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE59_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE59_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE59_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE59_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE59_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE59_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE59_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE59_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE59_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE59_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE59_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE59_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE59_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE59_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE59_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE59_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE59_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE59_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE59_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE59_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE59_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE59_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE59_LOCK1
// Description : Lock configuration MSBs for page 59 (addresses 0x1d80 through
//               0x1dff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE59_LOCK1_OFFSET _u(0x00001fee)
#define OTP_DATA_PAGE59_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE59_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE59_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE59_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE59_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE59_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE59_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE59_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE59_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE59_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE59_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE59_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE59_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE59_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE59_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE59_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE59_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE59_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE59_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE59_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE59_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE59_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE59_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE59_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE59_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE59_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE59_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE59_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE59_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE59_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE59_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE59_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE59_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE59_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE59_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE59_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE59_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE59_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE59_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE59_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE59_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE59_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE59_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE59_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE60_LOCK0
// Description : Lock configuration LSBs for page 60 (addresses 0x1e00 through
//               0x1e7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE60_LOCK0_OFFSET _u(0x00001ff0)
#define OTP_DATA_PAGE60_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE60_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE60_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE60_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE60_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE60_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE60_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE60_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE60_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE60_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE60_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE60_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE60_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE60_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE60_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE60_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE60_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE60_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE60_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE60_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE60_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE60_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE60_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE60_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE60_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE60_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE60_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE60_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE60_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE60_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE60_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE60_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE60_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE60_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE60_LOCK1
// Description : Lock configuration MSBs for page 60 (addresses 0x1e00 through
//               0x1e7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE60_LOCK1_OFFSET _u(0x00001ff2)
#define OTP_DATA_PAGE60_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE60_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE60_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE60_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE60_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE60_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE60_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE60_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE60_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE60_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE60_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE60_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE60_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE60_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE60_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE60_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE60_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE60_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE60_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE60_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE60_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE60_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE60_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE60_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE60_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE60_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE60_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE60_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE60_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE60_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE60_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE60_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE60_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE60_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE60_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE60_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE60_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE60_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE60_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE60_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE60_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE60_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE60_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE60_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE61_LOCK0
// Description : Lock configuration LSBs for page 61 (addresses 0x1e80 through
//               0x1eff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE61_LOCK0_OFFSET _u(0x00001ff4)
#define OTP_DATA_PAGE61_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE61_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE61_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE61_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE61_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE61_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE61_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE61_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE61_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE61_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE61_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE61_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE61_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE61_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE61_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE61_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE61_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE61_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE61_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE61_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE61_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE61_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE61_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE61_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE61_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE61_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE61_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE61_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE61_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE61_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE61_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE61_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE61_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE61_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE61_LOCK1
// Description : Lock configuration MSBs for page 61 (addresses 0x1e80 through
//               0x1eff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE61_LOCK1_OFFSET _u(0x00001ff6)
#define OTP_DATA_PAGE61_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE61_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE61_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE61_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE61_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE61_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE61_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE61_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE61_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE61_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE61_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE61_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE61_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE61_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE61_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE61_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE61_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE61_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE61_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE61_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE61_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE61_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE61_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE61_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE61_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE61_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE61_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE61_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE61_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE61_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE61_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE61_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE61_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE61_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE61_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE61_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE61_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE61_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE61_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE61_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE61_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE61_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE61_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE61_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE62_LOCK0
// Description : Lock configuration LSBs for page 62 (addresses 0x1f00 through
//               0x1f7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE62_LOCK0_OFFSET _u(0x00001ff8)
#define OTP_DATA_PAGE62_LOCK0_BITS   _u(0x00ffff7f)
#define OTP_DATA_PAGE62_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE62_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE62_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE62_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE62_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE62_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE62_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE62_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE62_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE62_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE62_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE62_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE62_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE62_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE62_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE62_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE62_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE62_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE62_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE62_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE62_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE62_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE62_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE62_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE62_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE62_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE62_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE62_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE62_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE62_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE62_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE62_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE62_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE62_LOCK1
// Description : Lock configuration MSBs for page 62 (addresses 0x1f00 through
//               0x1f7f). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE62_LOCK1_OFFSET _u(0x00001ffa)
#define OTP_DATA_PAGE62_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE62_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE62_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE62_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE62_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE62_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE62_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE62_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE62_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE62_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE62_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE62_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE62_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE62_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE62_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE62_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE62_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE62_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE62_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE62_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE62_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE62_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE62_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE62_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE62_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE62_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE62_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE62_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE62_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE62_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE62_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE62_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE62_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE62_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE62_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE62_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE62_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE62_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE62_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE62_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE62_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE62_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE62_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE62_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
// Register    : OTP_DATA_PAGE63_LOCK0
// Description : Lock configuration LSBs for page 63 (addresses 0x1f80 through
//               0x1fff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE63_LOCK0_OFFSET _u(0x00001ffc)
#define OTP_DATA_PAGE63_LOCK0_BITS   _u(0x00ffffff)
#define OTP_DATA_PAGE63_LOCK0_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK0_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE63_LOCK0_R2_RESET  "-"
#define OTP_DATA_PAGE63_LOCK0_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE63_LOCK0_R2_MSB    _u(23)
#define OTP_DATA_PAGE63_LOCK0_R2_LSB    _u(16)
#define OTP_DATA_PAGE63_LOCK0_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK0_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE63_LOCK0_R1_RESET  "-"
#define OTP_DATA_PAGE63_LOCK0_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE63_LOCK0_R1_MSB    _u(15)
#define OTP_DATA_PAGE63_LOCK0_R1_LSB    _u(8)
#define OTP_DATA_PAGE63_LOCK0_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK0_RMA
// Description : Decommission for RMA of a suspected faulty device. This
//               re-enables the factory test JTAG interface, and makes pages 2
//               through 61 of the OTP permanently inaccessible.
#define OTP_DATA_PAGE63_LOCK0_RMA_RESET  "-"
#define OTP_DATA_PAGE63_LOCK0_RMA_BITS   _u(0x00000080)
#define OTP_DATA_PAGE63_LOCK0_RMA_MSB    _u(7)
#define OTP_DATA_PAGE63_LOCK0_RMA_LSB    _u(7)
#define OTP_DATA_PAGE63_LOCK0_RMA_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK0_NO_KEY_STATE
// Description : State when at least one key is registered for this page and no
//               matching key has been entered.
//               0x0 -> read_only
//               0x1 -> inaccessible
#define OTP_DATA_PAGE63_LOCK0_NO_KEY_STATE_RESET              "-"
#define OTP_DATA_PAGE63_LOCK0_NO_KEY_STATE_BITS               _u(0x00000040)
#define OTP_DATA_PAGE63_LOCK0_NO_KEY_STATE_MSB                _u(6)
#define OTP_DATA_PAGE63_LOCK0_NO_KEY_STATE_LSB                _u(6)
#define OTP_DATA_PAGE63_LOCK0_NO_KEY_STATE_ACCESS             "RO"
#define OTP_DATA_PAGE63_LOCK0_NO_KEY_STATE_VALUE_READ_ONLY    _u(0x0)
#define OTP_DATA_PAGE63_LOCK0_NO_KEY_STATE_VALUE_INACCESSIBLE _u(0x1)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK0_KEY_R
// Description : Index 1-6 of a hardware key which must be entered to grant read
//               access, or 0 if no such key is required.
#define OTP_DATA_PAGE63_LOCK0_KEY_R_RESET  "-"
#define OTP_DATA_PAGE63_LOCK0_KEY_R_BITS   _u(0x00000038)
#define OTP_DATA_PAGE63_LOCK0_KEY_R_MSB    _u(5)
#define OTP_DATA_PAGE63_LOCK0_KEY_R_LSB    _u(3)
#define OTP_DATA_PAGE63_LOCK0_KEY_R_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK0_KEY_W
// Description : Index 1-6 of a hardware key which must be entered to grant
//               write access, or 0 if no such key is required.
#define OTP_DATA_PAGE63_LOCK0_KEY_W_RESET  "-"
#define OTP_DATA_PAGE63_LOCK0_KEY_W_BITS   _u(0x00000007)
#define OTP_DATA_PAGE63_LOCK0_KEY_W_MSB    _u(2)
#define OTP_DATA_PAGE63_LOCK0_KEY_W_LSB    _u(0)
#define OTP_DATA_PAGE63_LOCK0_KEY_W_ACCESS "RO"
// =============================================================================
// Register    : OTP_DATA_PAGE63_LOCK1
// Description : Lock configuration MSBs for page 63 (addresses 0x1f80 through
//               0x1fff). Locks are stored with 3-way majority vote encoding, so
//               that bits can be set independently.
//
//               This OTP location is always readable, and is write-protected by
//               its own permissions.
#define OTP_DATA_PAGE63_LOCK1_OFFSET _u(0x00001ffe)
#define OTP_DATA_PAGE63_LOCK1_BITS   _u(0x00ffff3f)
#define OTP_DATA_PAGE63_LOCK1_RESET  _u(0x00000000)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK1_R2
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE63_LOCK1_R2_RESET  "-"
#define OTP_DATA_PAGE63_LOCK1_R2_BITS   _u(0x00ff0000)
#define OTP_DATA_PAGE63_LOCK1_R2_MSB    _u(23)
#define OTP_DATA_PAGE63_LOCK1_R2_LSB    _u(16)
#define OTP_DATA_PAGE63_LOCK1_R2_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK1_R1
// Description : Redundant copy of bits 7:0
#define OTP_DATA_PAGE63_LOCK1_R1_RESET  "-"
#define OTP_DATA_PAGE63_LOCK1_R1_BITS   _u(0x0000ff00)
#define OTP_DATA_PAGE63_LOCK1_R1_MSB    _u(15)
#define OTP_DATA_PAGE63_LOCK1_R1_LSB    _u(8)
#define OTP_DATA_PAGE63_LOCK1_R1_ACCESS "RO"
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK1_LOCK_BL
// Description : Dummy lock bits reserved for bootloaders (including the RP2350
//               USB bootloader) to store their own OTP access permissions. No
//               hardware effect, and no corresponding SW_LOCKx registers.
//               0x0 -> Bootloader permits user reads and writes to this page
//               0x1 -> Bootloader permits user reads of this page
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE
//               0x3 -> Bootloader does not permit user access to this page
#define OTP_DATA_PAGE63_LOCK1_LOCK_BL_RESET              "-"
#define OTP_DATA_PAGE63_LOCK1_LOCK_BL_BITS               _u(0x00000030)
#define OTP_DATA_PAGE63_LOCK1_LOCK_BL_MSB                _u(5)
#define OTP_DATA_PAGE63_LOCK1_LOCK_BL_LSB                _u(4)
#define OTP_DATA_PAGE63_LOCK1_LOCK_BL_ACCESS             "RO"
#define OTP_DATA_PAGE63_LOCK1_LOCK_BL_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE63_LOCK1_LOCK_BL_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE63_LOCK1_LOCK_BL_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE63_LOCK1_LOCK_BL_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK1_LOCK_NS
// Description : Lock state for NonSecure accesses to this page.
//               Thermometer-coded, so lock state can be advanced permanently
//               from any state to any less-permissive state by programming OTP.
//               Software can also advance the lock state temporarily (until
//               next OTP reset) using the SW_LOCKx registers.
//
//               Note that READ_WRITE and READ_ONLY are equivalent in hardware,
//               as the SBPI programming interface is not accessible to
//               NonSecure software. However, Secure software may check these
//               bits to apply write permissions to a NonSecure OTP programming
//               API.
//               0x0 -> Page can be read by NonSecure software, and Secure
//               software may permit NonSecure writes.
//               0x1 -> Page can be read by NonSecure software
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by NonSecure software.
#define OTP_DATA_PAGE63_LOCK1_LOCK_NS_RESET              "-"
#define OTP_DATA_PAGE63_LOCK1_LOCK_NS_BITS               _u(0x0000000c)
#define OTP_DATA_PAGE63_LOCK1_LOCK_NS_MSB                _u(3)
#define OTP_DATA_PAGE63_LOCK1_LOCK_NS_LSB                _u(2)
#define OTP_DATA_PAGE63_LOCK1_LOCK_NS_ACCESS             "RO"
#define OTP_DATA_PAGE63_LOCK1_LOCK_NS_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE63_LOCK1_LOCK_NS_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE63_LOCK1_LOCK_NS_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE63_LOCK1_LOCK_NS_VALUE_INACCESSIBLE _u(0x3)
// -----------------------------------------------------------------------------
// Field       : OTP_DATA_PAGE63_LOCK1_LOCK_S
// Description : Lock state for Secure accesses to this page. Thermometer-coded,
//               so lock state can be advanced permanently from any state to any
//               less-permissive state by programming OTP. Software can also
//               advance the lock state temporarily (until next OTP reset) using
//               the SW_LOCKx registers.
//               0x0 -> Page is fully accessible by Secure software.
//               0x1 -> Page can be read by Secure software, but can not be
//               written.
//               0x2 -> Do not use. Behaves the same as INACCESSIBLE.
//               0x3 -> Page can not be accessed by Secure software.
#define OTP_DATA_PAGE63_LOCK1_LOCK_S_RESET              "-"
#define OTP_DATA_PAGE63_LOCK1_LOCK_S_BITS               _u(0x00000003)
#define OTP_DATA_PAGE63_LOCK1_LOCK_S_MSB                _u(1)
#define OTP_DATA_PAGE63_LOCK1_LOCK_S_LSB                _u(0)
#define OTP_DATA_PAGE63_LOCK1_LOCK_S_ACCESS             "RO"
#define OTP_DATA_PAGE63_LOCK1_LOCK_S_VALUE_READ_WRITE   _u(0x0)
#define OTP_DATA_PAGE63_LOCK1_LOCK_S_VALUE_READ_ONLY    _u(0x1)
#define OTP_DATA_PAGE63_LOCK1_LOCK_S_VALUE_RESERVED     _u(0x2)
#define OTP_DATA_PAGE63_LOCK1_LOCK_S_VALUE_INACCESSIBLE _u(0x3)
// =============================================================================
#endif // HARDWARE_REGS_OTP_DATA_DEFINED
